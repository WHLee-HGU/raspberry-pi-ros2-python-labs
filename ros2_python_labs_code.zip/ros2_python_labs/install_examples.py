"""배포된 수업용 SD에 새 예제와 손동작 모델만 추가한다. apt/pip 설치 없음."""
import argparse
from datetime import datetime, timezone
import hashlib
import os
from pathlib import Path
import shutil
import sys
import uuid

MODEL_SHA256 = '97952348cf6a6a4915c2ea1496b4b37ebabc50cbbf80571435643c455f2b0482'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, default=Path.home()/'pi_basics_6h')
    parser.add_argument('--check', action='store_true', help='설치할 파일과 대상만 확인')
    args = parser.parse_args()
    source = Path(__file__).resolve().parent
    project = args.project.expanduser().resolve()
    target = project/'ros2_python_labs'
    model_source = source/'assets/models/gesture_recognizer.task'
    if not (project/'classroom.sh').is_file():
        raise SystemExit('기존 수업 프로젝트의 classroom.sh를 찾지 못했습니다: '+str(project))
    if not model_source.is_file() or digest(model_source) != MODEL_SHA256:
        raise SystemExit('동봉한 손동작 모델의 파일 또는 SHA256이 다릅니다.')
    files = [(item, target/'code'/item.name) for item in sorted((source/'code').glob('*.py'))]
    for name in ['run_lab.sh', 'README_실행방법.txt', 'MODEL_SOURCE.txt', 'AI_코드해설.txt']:
        if (source/name).is_file():
            files.append((source/name, target/name))
    files.append((model_source, project/'models/gesture_recognizer.task'))
    if not files or len(list((source/'code').glob('*.py'))) < 15:
        raise SystemExit('예제 코드가 불완전합니다. 배포 ZIP 전체를 먼저 풉니다.')
    print('추가할 예제:', target)
    print('파일 수:', len(files))
    if args.check:
        print('읽기 전용 점검입니다. 기존 프로젝트/컨테이너를 변경하지 않았습니다.')
        return
    if hasattr(os, 'geteuid') and os.geteuid() == 0:
        raise SystemExit('sudo 없이 평소 student 계정으로 실행하세요.')
    for _src, destination in files:
        for ancestor in [destination, *destination.parents]:
            if ancestor.is_symlink():
                raise SystemExit('심볼릭 링크 경로에는 자동 복사하지 않습니다: '+str(ancestor))
            if ancestor == project:
                break
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:6]
    backup = project/'ros2_python_labs_backups'/stamp
    for ancestor in [backup, *backup.parents]:
        if ancestor.is_symlink():
            raise SystemExit('백업 폴더의 심볼릭 링크 경로에는 복사하지 않습니다: '+str(ancestor))
        if ancestor == project:
            break
    changed = 0
    for item, destination in files:
        if item.resolve() == destination.resolve():
            continue
        if destination.is_file() and digest(item) == digest(destination):
            continue
        if destination.exists():
            saved = backup/destination.relative_to(project)
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(destination, saved)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(item, destination)
        changed += 1
    (target/'data').mkdir(parents=True, exist_ok=True)
    print('추가/갱신 파일:', changed)
    if backup.exists():
        print('덮어쓴 기존 파일의 원본 백업:', backup)
    print('다음: cd '+str(target)+' && bash run_lab.sh check')


if __name__ == '__main__':
    main()
