#!/usr/bin/env bash
set -euo pipefail
source_dir="$(cd "$(dirname "$0")" && pwd)"
exec /usr/bin/python3 "$source_dir/install_examples.py" "$@"
