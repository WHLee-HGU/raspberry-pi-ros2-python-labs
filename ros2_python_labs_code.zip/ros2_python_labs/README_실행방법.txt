라즈베리파이 6시간 수업: Python ROS2 확장 실습

1. 어디에 설치하나요?
기존 수업용 SD의 일반 사용자(student)로 ZIP 전체의 압축을 풉니다.
압축을 푼 ros2_python_labs 폴더에서 다음 한 줄을 실행합니다.
  bash install_on_pi.sh
apt/pip 설치나 SD 재기록은 하지 않습니다. 기존 GPIO/AI 가상환경과 pi-class 컨테이너를 사용합니다.
새 코드는 ~/pi_basics_6h/ros2_python_labs 에, 새 손동작 모델은 기존 models 폴더에 추가합니다.
덮어쓸 파일의 내용이 다르면 원본을 ros2_python_labs_backups에 먼저 보관합니다.

설치 후:
  cd ~/pi_basics_6h/ros2_python_labs
  bash run_lab.sh check
모든 명령은 파이 OS의 일반 터미널에서 실행합니다.
run_lab.sh가 ROS 노드를 기존 Docker 컨테이너 안에서 실행해 줍니다.
이 실습에서는 classroom.sh enter를 먼저 실행할 필요가 없습니다.

2. 메시지 내용과 타입
문자 보내기와 받기: 서로 다른 두 터미널에서 각각 실행합니다.
  bash run_lab.sh text-pub --message '우리 조의 메시지'
  bash run_lab.sh text-sub
코드에서 고칠 곳:
  code/text_publisher.py의 --message 기본값 또는 message.data에 넣는 문자열.
  --topic을 바꾸면 publisher/listener 양쪽에 같은 토픽을 지정합니다.
숫자(Float32)로 바꾼 비교 예제:
  bash run_lab.sh number-pub --value 42.5
  bash run_lab.sh number-sub
String은 문자 data, Float32는 숫자 data를 사용합니다.
타입을 바꿀 때 양쪽 import, create_publisher/create_subscription,
메시지 객체 생성과 필드의 값 타입을 함께 맞춥니다. 다른 타입으로 같은 토픽을 쓰지 않습니다.
기본 설치 예제(demo_nodes_cpp/py)의 파일은 수정하지 않습니다.

3. 초음파 거리와 LED 밝기
BCM 번호를 사용합니다. PWM LED BCM18=물리12번, TRIG BCM23=물리16번,
ECHO BCM24=물리18번, 5V=물리2/4번, GND=물리6번 등입니다.
LED는 BCM18 -> 330Ω 저항 -> LED 긴 다리(+), LED 짧은 다리(-) -> GND.
HC-SR04 ECHO 5V는 기존 교재의 1kΩ/2kΩ 분압을 거쳐 BCM24에 연결합니다.
전원을 끄고 배선한 다음 다시 켭니다. ECHO를 GPIO에 직접 연결하지 않습니다.

세 터미널에서 각각 다음을 실행합니다.
  A: cd ~/pi_basics_6h/ros2_python_labs && bash run_lab.sh io-range
  B: cd ~/pi_basics_6h/ros2_python_labs && bash run_lab.sh range-pub
  C: cd ~/pi_basics_6h/ros2_python_labs && bash run_lab.sh range-sub
A는 호스트 센서/LED 도우미, B는 ROS publisher, C는 ROS listener입니다.
  code/distance_sensor.py: 초음파 측정값(m)을 공유 파일에 남깁니다.
  code/distance_publisher.py: sensor_msgs/Range의 range 필드로 발행합니다.
  code/distance_led_listener.py: 거리를 0~1 밝기로 바꿔 출력 명령을 남깁니다.
  code/led_output.py: 명령에 따라 실제 GPIO의 PWM을 설정합니다.
10cm 이하면 최대 밝기, 80cm 이상이면 꺼짐, 사이 구간은 선형으로 바뀝니다.
기본 측정 범위 2~200cm 밖의 값/측정 실패/1초 이상 오래된 값은 꺼짐입니다.
기준 변경은 C에서 --near-cm 15 --far-cm 60처럼 지정합니다.
PWM 핀 변경은 A에서 --pwm-pin 18처럼 BCM 번호로 지정합니다.
GPIOZero/lgpio의 소프트웨어 PWM을 쓰며 하드웨어 PWM 주변장치를 직접 설정하지 않습니다.

배선 없이 프로그램만 점검할 때 A에 --mock을 붙입니다.
  bash run_lab.sh io-range --mock
실제 센서/LED를 쓰지 않는 모의 실행임을 기록합니다.
B와 C는 같은 실제 ROS2 노드로 실행하며, A에 적용 예정 밝기가 출력됩니다.

4. 손동작과 빨강/파랑 LED
빨강 LED BCM6=물리31번, 파랑 LED BCM13=물리33번.
각 LED마다 330Ω 직렬 저항과 공통 GND를 연결합니다.
카메라는 전원을 분리한 상태에서 CAM/DISP0에 연결합니다.
세 터미널:
  A: bash run_lab.sh io-hand
  B: bash run_lab.sh hand-pub
  C: bash run_lab.sh hand-sub
공식 Gesture Recognizer의 Closed_Fist/Open_Palm 결과가
신뢰도 0.6 이상으로 3프레임 이어지면 FIST/OPEN으로 확정합니다.
FIST는 빨강, OPEN은 파랑. 손 없음/두 손/다른 동작/오래된 값은 둘 다 꺼집니다.
새 모델 gesture_recognizer.task가 필요하며 설치 스크립트가 동봉 모델을 복사합니다.
영상 창이 필요 없으면 A에 --headless를 붙입니다.
배선과 카메라 없이 시험하면 A에 --mock을 붙입니다.

5. 스마트폰 감지 알림등
세 터미널:
  A: bash run_lab.sh io-phone
  B: bash run_lab.sh phone-pub
  C: bash run_lab.sh phone-sub
기존 YOLO11n NCNN 모델에서 cell phone을 신뢰도 0.5 이상으로 검출합니다.
연속 2프레임 검출은 PHONE(빨강 LED 1Hz 점멸),
0.5초 동안 연속 미검출은 CLEAR(파랑 LED), 미확인은 둘 다 꺼짐입니다.
CLEAR는 카메라가 보던 프레임에서 스마트폰을 검출하지 않았다는 뜻입니다.
감지 결과를 휴대폰 사용 여부나 교칙 위반의 확정 판단으로 쓰지 않습니다.
영상이나 사진을 자동 저장하지 않습니다.
손동작/YOLO 실습은 하나씩 진행합니다. 같은 카메라와 LED를 동시에 점유하지 않습니다.

6. 데이터가 실제로 이동하는 경로
호스트 센서/AI -> 공유 JSON 결과 파일 -> 컨테이너 publisher -> ROS2 토픽
-> 컨테이너 listener -> 공유 JSON 명령 파일 -> 호스트 LED 출력.
카메라 영상 자체는 ROS 메시지로 보내지 않고 거리/인식 결과만 전달합니다.
ROS2는 반드시 Docker가 필요한 것은 아닙니다. 이 수업에서는 Bookworm의
GPIO/카메라 환경을 유지하면서 Ubuntu 기반 ROS2 Humble 환경을 쓰려고 Docker를 선택했습니다.
호스트 Python3.11의 .venv와 컨테이너 Python3.10/rclpy를 한 Python처럼 섞지 않습니다.

7. 종료
각 터미널에서 Ctrl+C로 종료합니다. A의 도우미는 LED를 끄고 카메라/GPIO를 정리합니다.
입력 중단 시험은 A 또는 B를 종료하고 나머지를 유지해 1초 내외 뒤 꺼짐을 확인합니다.
전체 3개 연동 실습을 학생 모두에게 6시간 안에 추가하지 않습니다.
본 수업은 초음파 ROS PWM, 손동작/YOLO 연동은 선택 실습 또는 교사 시연으로 사용합니다.

8. 근거
ROS2 Python 예제: https://github.com/ros2/demos/tree/humble/demo_nodes_py
메시지 정의: https://github.com/ros2/common_interfaces/tree/humble
Docker: https://docs.docker.com/get-started/docker-concepts/the-basics/what-is-a-container/
Python venv: https://docs.python.org/3.11/library/venv.html
MediaPipe: https://developers.google.com/edge/mediapipe/solutions/vision/gesture_recognizer/python
YOLO: https://docs.ultralytics.com/modes/predict/
