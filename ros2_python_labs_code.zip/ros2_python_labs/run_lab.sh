#!/usr/bin/env bash
# 이 명령은 파이 OS의 일반 터미널에서 실행합니다.
set -euo pipefail
lab_dir="$(cd "$(dirname "$0")" && pwd)"
project_dir="$(dirname "$lab_dir")"
mkdir -p "$lab_dir/data"
action="${1:-help}"
if (($#)); then shift; fi
case "$action" in
  io-range|io-hand|io-phone)
    exec /usr/bin/python3 "$lab_dir/code/io_session.py" "${action#io-}" "$@" ;;
  text-pub) node=text_publisher.py ;;
  text-sub) node=text_listener.py ;;
  number-pub) node=number_publisher.py ;;
  number-sub) node=number_listener.py ;;
  range-pub) node=distance_publisher.py ;;
  range-sub) node=distance_led_listener.py ;;
  hand-pub) node=hand_publisher.py ;;
  hand-sub) node=hand_led_listener.py ;;
  phone-pub) node=phone_publisher.py ;;
  phone-sub) node=phone_led_listener.py ;;
  check)
    exec /usr/bin/python3 "$lab_dir/code/check_installation.py" ;;
  *)
    echo '파이 OS 터미널에서: bash run_lab.sh {check|text-pub|text-sub|number-pub|number-sub}'
    echo '초음파: io-range / range-pub / range-sub (서로 다른 세 터미널)'
    echo '손동작: io-hand / hand-pub / hand-sub'
    echo '스마트폰: io-phone / phone-pub / phone-sub'
    echo '배선 없이 확인: io-range --mock 또는 io-hand --mock 또는 io-phone --mock'
    exit 0 ;;
esac
# 이 강의의 pi-class 컨테이너와 같은 공유 폴더인지 먼저 확인한다.
sudo docker inspect pi-class --format '{{range .Mounts}}{{if eq .Destination "/work"}}{{.Source}}{{end}}{{end}}' |
  /usr/bin/python3 -c 'import pathlib,sys; expected=pathlib.Path(sys.argv[1]).resolve(); actual=sys.stdin.read().strip(); assert actual and pathlib.Path(actual).resolve()==expected,"기존 pi-class 컨테이너의 /work 공유 폴더가 다릅니다."' "$project_dir"
sudo docker start pi-class >/dev/null
terminal_options=(-i)
if [[ -t 0 && -t 1 ]]; then terminal_options=(-it); fi
exec sudo docker exec "${terminal_options[@]}" -e PYTHONUNBUFFERED=1 pi-class bash -c \
  'source /opt/ros/humble/setup.bash; exec python3 "/work/ros2_python_labs/code/$1" "${@:2}"' bash "$node" "$@"
