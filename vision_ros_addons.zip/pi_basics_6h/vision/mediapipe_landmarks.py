"""손·얼굴·전신의 특징점과 연결선을 표시하는 MediaPipe Tasks 예제.

cd ~/pi_basics_6h
.venv-mp/bin/python vision/mediapipe_landmarks.py --mode hands
--mode face / pose / all 로 인식 대상을 바꿉니다. Q 또는 Ctrl+C로 종료합니다.
사진·영상 파일을 저장하지 않으며 GPIO와 ROS를 사용하지 않습니다.
"""
import argparse
from contextlib import ExitStack
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import tempfile
import time
import urllib.request
import zipfile


# 버전을 고정한 Google 공식 모델. 얼굴/전신도 각각 별도의 모델이 필요합니다.
MODEL_ROOT = 'https://storage.googleapis.com/mediapipe-models/'
MODELS = {
    'hands': ('hand_landmarker.task',
              'hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task',
              'fbc2a30080c3c557093b5ddfc334698132eb341044ccee322ccf8bcf3607cde1'),
    'face': ('face_landmarker.task',
             'face_landmarker/face_landmarker/float16/1/face_landmarker.task',
             '64184e229b263107bc2b804c6625db1341ff2bb731874b0bcc2fe6544e0bc9ff'),
    'pose': ('pose_landmarker_lite.task',
             'pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task',
             '59929e1d1ee95287735ddd833b19cf4ac46d29bc7afddbbf6753c459690d574a'),
}
WINDOW = 'MediaPipe landmarks - Q to quit'


def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=['hands', 'face', 'pose', 'all'], default='hands')
    parser.add_argument('--source', default='picamera2',
                        help='picamera2: CSI 카메라, 0: USB 카메라, 또는 영상 파일 경로')
    parser.add_argument('--camera-index', type=int, default=0,
                        help='CSI 카메라 목록의 번호. 물리 CAM0/CAM1 번호가 아닙니다.')
    parser.add_argument('--duration', type=float, default=0,
                        help='실행 시간(초). 0이면 Q 또는 Ctrl+C까지 실행합니다.')
    parser.add_argument('--headless', action='store_true', help='영상 창 없이 추론 결과만 출력')
    parser.add_argument('--model-dir', type=Path,
                        default=Path(__file__).resolve().parents[1] / 'models')
    parser.add_argument('--prepare-models', action='store_true',
                        help='선택한 모드의 모델만 미리 받고 종료. 카메라를 사용하지 않습니다.')
    args = parser.parse_args()
    if args.camera_index < 0:
        parser.error('--camera-index는 0 이상이어야 합니다.')
    if not math.isfinite(args.duration) or args.duration < 0:
        parser.error('--duration은 0 이상의 유한한 초 값이어야 합니다.')
    if not args.source.strip():
        parser.error('--source를 비워 둘 수 없습니다.')
    return args


def verify_model(path, expected_sha):
    if expected_sha and hashlib.sha256(path.read_bytes()).hexdigest() != expected_sha:
        raise RuntimeError(f'모델 SHA256이 다릅니다: {path}')
    # .task는 여러 TFLite 모델을 담은 ZIP 묶음입니다.
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None or not archive.namelist():
            raise RuntimeError(f'모델 파일이 손상되었습니다: {path}')


def ensure_model(mode, directory):
    filename, relative_url, expected_sha = MODELS[mode]
    directory.mkdir(parents=True, exist_ok=True)
    destination = directory / filename
    if destination.is_file():
        verify_model(destination, expected_sha)
        return destination
    print(f'Model download (first run): {filename}', flush=True)
    temporary = None
    try:
        # 다운로드 중 실패하면 불완전한 파일을 정식 모델 이름으로 남기지 않습니다.
        with tempfile.NamedTemporaryFile(dir=directory, suffix='.download', delete=False) as output:
            temporary = Path(output.name)
            with urllib.request.urlopen(MODEL_ROOT + relative_url, timeout=30) as response:
                received = 0
                while chunk := response.read(1024 * 1024):
                    received += len(chunk)
                    if received > 64 * 1024 * 1024:
                        raise RuntimeError('모델 다운로드가 예상 크기(64MB)를 초과했습니다.')
                    output.write(chunk)
            output.flush()
            os.fsync(output.fileno())
        verify_model(temporary, expected_sha)
        temporary.replace(destination)
        print(f'Model ready: {destination}', flush=True)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    return destination


class Camera:
    """OpenCV에서 사용할 BGR 프레임을 공급합니다."""

    def __init__(self, source, camera_index, cv2):
        self.picam = self.capture = None
        self.started = False
        try:
            if source == 'picamera2':
                from picamera2 import Picamera2
                from libcamera import controls
                cameras = Picamera2.global_camera_info()
                if not any(item['Num'] == camera_index for item in cameras):
                    raise RuntimeError('해당 CSI 카메라가 없습니다. rpicam-hello --list-cameras로 확인하세요.')
                self.picam = Picamera2(camera_index)
                configuration = self.picam.create_video_configuration(
                    main={'size': (640, 480), 'format': 'RGB888'}, buffer_count=4)
                self.picam.configure(configuration)
                if 'AfMode' in self.picam.camera_controls:
                    self.picam.set_controls({'AfMode': controls.AfModeEnum.Continuous})
                self.picam.start()
                self.started = True
                time.sleep(0.5)
                print(f'CSI software camera index={camera_index}', flush=True)
            else:
                self.capture = cv2.VideoCapture(int(source) if source.isdecimal() else source)
                self.capture.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
                self.capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
                if not self.capture.isOpened():
                    raise RuntimeError('USB 카메라 또는 영상 파일을 열지 못했습니다.')
        except BaseException:
            self.close()
            raise

    def read(self):
        if self.picam is not None:
            # Picamera2의 RGB888 메모리 순서는 BGR이므로 OpenCV에 바로 전달합니다.
            return True, self.picam.capture_array('main')
        return self.capture.read()

    def close(self):
        if self.picam is not None:
            try:
                if self.started:
                    self.picam.stop()
            finally:
                self.picam.close()
                self.picam = None
        if self.capture is not None:
            self.capture.release()
            self.capture = None


def make_detector(mode, path, vision, tasks_python):
    base = tasks_python.BaseOptions(model_asset_path=str(path))
    common = {'base_options': base, 'running_mode': vision.RunningMode.VIDEO}
    if mode == 'hands':
        options = vision.HandLandmarkerOptions(**common, num_hands=2)
        return vision.HandLandmarker.create_from_options(options)
    if mode == 'face':
        options = vision.FaceLandmarkerOptions(**common, num_faces=1)
        return vision.FaceLandmarker.create_from_options(options)
    options = vision.PoseLandmarkerOptions(**common, num_poses=1)
    return vision.PoseLandmarker.create_from_options(options)


def connections(mode, vision):
    if mode == 'hands':
        return vision.HandLandmarksConnections.HAND_CONNECTIONS
    if mode == 'face':
        face = vision.FaceLandmarksConnections
        return (list(face.FACE_LANDMARKS_CONTOURS)
                + list(face.FACE_LANDMARKS_LEFT_IRIS)
                + list(face.FACE_LANDMARKS_RIGHT_IRIS))
    return vision.PoseLandmarksConnections.POSE_LANDMARKS


def draw_landmarks(frame, landmarks, edges, mode, cv2):
    height, width = frame.shape[:2]
    points = {}
    for index, landmark in enumerate(landmarks):
        # 전신 추정에서는 가려져 신뢰도가 낮은 관절을 그리지 않습니다.
        visibility = getattr(landmark, 'visibility', None)
        presence = getattr(landmark, 'presence', None)
        if mode == 'pose' and any(value is not None and value < 0.5
                                  for value in (visibility, presence)):
            continue
        if not (math.isfinite(landmark.x) and math.isfinite(landmark.y)
                and 0 <= landmark.x < 1 and 0 <= landmark.y < 1):
            continue
        points[index] = (int(landmark.x * width), int(landmark.y * height))
    color = {'hands': (0, 255, 0), 'face': (0, 200, 255), 'pose': (255, 255, 0)}[mode]
    for edge in edges:
        if edge.start in points and edge.end in points:
            cv2.line(frame, points[edge.start], points[edge.end], color, 2)
    for point in points.values():
        cv2.circle(frame, point, 1 if mode == 'face' else 3, (255, 0, 255), -1)


def main():
    args = arguments()
    modes = list(MODELS) if args.mode == 'all' else [args.mode]
    paths = {mode: ensure_model(mode, args.model_dir) for mode in modes}
    if args.prepare_models:
        print('Selected models are ready. No camera opened.', flush=True)
        return
    # --help와 모델 사전 준비에는 MediaPipe/OpenCV 설치가 필요하지 않습니다.
    import cv2
    import mediapipe as mp
    from mediapipe.tasks import python as tasks_python
    from mediapipe.tasks.python import vision

    def stop(signum, frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, stop)
    if args.mode == 'all':
        print('ALL mode runs 3 models sequentially; expect a lower frame rate.', flush=True)
    frames = 0
    detected_frames = {mode: 0 for mode in modes}
    started, last_ms, last_report = time.monotonic(), -1, 0.0
    reason = 'duration'
    try:
        with ExitStack() as cleanup:
            if not args.headless:
                cleanup.callback(cv2.destroyAllWindows)
                cv2.namedWindow(WINDOW, cv2.WINDOW_NORMAL)
                cv2.resizeWindow(WINDOW, 800, 600)
            detectors = {mode: cleanup.enter_context(make_detector(mode, paths[mode], vision, tasks_python))
                         for mode in modes}
            edges = {mode: connections(mode, vision) for mode in modes}
            camera = Camera(args.source, args.camera_index, cv2)
            cleanup.callback(camera.close)
            started = time.monotonic()
            while args.duration == 0 or time.monotonic() - started < args.duration:
                ok, frame = camera.read()
                if not ok:
                    if args.source != 'picamera2' and not args.source.isdecimal() and frames:
                        reason = 'end_of_video'
                        break
                    raise RuntimeError('카메라 프레임을 받지 못했습니다.')
                # 1. OpenCV BGR → MediaPipe RGB, 2. 추론, 3. 점과 연결선 표시.
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
                last_ms = max(last_ms + 1, time.monotonic_ns() // 1_000_000)
                counts = {}
                for mode in modes:
                    result = detectors[mode].detect_for_video(image, last_ms)
                    field = {'hands': 'hand_landmarks', 'face': 'face_landmarks', 'pose': 'pose_landmarks'}[mode]
                    detected = getattr(result, field)
                    counts[mode] = len(detected)
                    detected_frames[mode] += bool(detected)
                    for landmarks in detected:
                        draw_landmarks(frame, landmarks, edges[mode], mode, cv2)
                frames += 1
                elapsed = time.monotonic() - started
                fps = frames / max(elapsed, 0.001)
                label = '  '.join(f'{mode}={counts[mode]}' for mode in modes)
                if elapsed - last_report >= 1:
                    print(f'{label}  FPS={fps:.1f}', flush=True)
                    last_report = elapsed
                if not args.headless:
                    cv2.putText(frame, f'{label}  FPS={fps:.1f}', (10, 25),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 0), 2)
                    cv2.imshow(WINDOW, frame)
                    if cv2.waitKey(1) & 0xff in (ord('q'), ord('Q'), 27):
                        reason = 'key'
                        break
                    if cv2.getWindowProperty(WINDOW, cv2.WND_PROP_VISIBLE) < 1:
                        reason = 'window_closed'
                        break
    except KeyboardInterrupt:
        reason = 'interrupted'
    except Exception:
        reason = 'error'
        raise
    finally:
        print(json.dumps({'mode': args.mode, 'frames': frames,
                          'detected_frames': detected_frames, 'exit_reason': reason,
                          'images_saved': False}), flush=True)


if __name__ == '__main__':
    main()
