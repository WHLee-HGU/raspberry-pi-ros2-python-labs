"""카메라/LED 호스트와 ROS2 컨테이너가 작은 JSON 결과를 공유합니다."""
import json
import os
from pathlib import Path
import signal
import tempfile

DATA_DIR = Path(os.environ.get('YOLO_POSITION_DATA_DIR', str(Path(__file__).resolve().parent/'data')))
NAMES = {'sample', 'command', 'applied'}


def _path(name):
    if name not in NAMES:
        raise ValueError('Unknown data name')
    return DATA_DIR/(name+'.json')


def write_json(name, record):
    if not isinstance(record, dict):
        raise TypeError('JSON record must be a dict')
    encoded = json.dumps(record, ensure_ascii=False, allow_nan=False).encode('utf-8')
    if len(encoded) > 65536:
        raise ValueError('Record is too large')
    target = _path(name)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix='.position-', dir=DATA_DIR)
    try:
        with os.fdopen(descriptor, 'wb') as stream:
            stream.write(encoded)
        os.chmod(temporary, 0o644)
        os.replace(temporary, target)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def read_json(name):
    try:
        with _path(name).open('rb') as stream:
            data = stream.read(65537)
        if len(data) > 65536:
            return None
        record = json.loads(data)
        return record if isinstance(record, dict) else None
    except (OSError, ValueError, TypeError, RecursionError):
        return None


def handle_termination():
    def stop(_signum, _frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, stop)
