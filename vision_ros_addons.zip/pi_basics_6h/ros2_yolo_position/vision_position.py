"""파이 OS의 .venv-yolo: 한 종류의 물체 중심을 찾아 ROS publisher에 전달합니다.

예: --target "cell phone" / --target bottle / --target cup
같은 종류가 여러 개면 신뢰도가 가장 높은 하나를 선택합니다. 개체 추적은 아닙니다.
영상은 좌우 반전하지 않습니다. 이미지의 왼쪽이 x=0, 오른쪽이 x=1입니다.
"""
import argparse
import json
import math
from pathlib import Path
import time


WINDOW = 'YOLO object position - Q to quit'


def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', default='cell phone', help='모델에 포함된 영어 물체 이름')
    parser.add_argument('--model', type=Path,
                        default=Path(__file__).resolve().parent.parent / 'models/yolo11n_ncnn_model')
    parser.add_argument('--conf', type=float, default=0.4)
    parser.add_argument('--imgsz', type=int, default=320)
    parser.add_argument('--source', default='picamera2', help='picamera2 / USB 번호 / 동영상 파일')
    parser.add_argument('--camera-index', type=int, default=0,
                        help='rpicam-hello --list-cameras에 나오는 소프트웨어 번호')
    parser.add_argument('--headless', action='store_true')
    parser.add_argument('--duration', type=float, default=0, help='초 단위, 0이면 Ctrl+C까지')
    parser.add_argument('--list-classes', action='store_true', help='준비된 모델의 물체 이름만 출력')
    parser.add_argument('--mock', action='store_true', help='YOLO/카메라 없이 위치값을 생성')
    parser.add_argument('--mock-x', type=float, help='모의 x를 0~1 중 한 값으로 고정')
    parser.add_argument('--mock-missing', action='store_true', help='모의 미검출 상태')
    args = parser.parse_args()
    if not math.isfinite(args.conf) or not 0 < args.conf <= 1:
        parser.error('--conf는 0보다 크고 1 이하인 유한한 값입니다.')
    if args.imgsz < 32 or args.imgsz % 32:
        parser.error('--imgsz는 32 이상의 32 배수입니다. 수업 기본값은 320입니다.')
    if args.camera_index < 0:
        parser.error('--camera-index는 0 이상입니다.')
    if not math.isfinite(args.duration) or args.duration < 0:
        parser.error('--duration은 0 이상의 유한한 초 값입니다.')
    if not args.target.strip() or not args.source.strip():
        parser.error('--target과 --source는 비워 둘 수 없습니다.')
    if args.mock_x is not None and (not math.isfinite(args.mock_x) or not 0 <= args.mock_x <= 1):
        parser.error('--mock-x는 0~1 범위입니다.')
    if (args.mock_x is not None or args.mock_missing) and not args.mock:
        parser.error('--mock-x와 --mock-missing은 --mock과 함께 사용합니다.')
    if args.mock and args.list_classes:
        parser.error('--list-classes는 실제 모델을 읽으므로 --mock과 함께 사용하지 않습니다.')
    if args.mock_x is not None and args.mock_missing:
        parser.error('--mock-x와 --mock-missing 중 하나만 사용하세요.')
    return args


def canonical_name(name):
    name = ' '.join(name.replace('_', ' ').strip().casefold().split())
    return {'phone': 'cell phone', 'smartphone': 'cell phone', 'cellphone': 'cell phone'}.get(name, name)


def load_model(path):
    if not path.exists():
        raise RuntimeError('준비된 YOLO 모델이 없습니다. 새 모델은 자동 설치하지 않습니다: ' + str(path))
    from ultralytics import YOLO
    model = YOLO(str(path), task='detect')
    names = model.names
    entries = names.items() if isinstance(names, dict) else enumerate(names)
    return model, {int(index): str(label) for index, label in entries}


def missing_sample(target, width=640, height=480, source_time=None):
    return {'schema': 1, 'target': target, 'detected': False,
            'cx_px': None, 'cy_px': None, 'width': width, 'height': height,
            'confidence': 0.0, 'source_time': time.time() if source_time is None else source_time}


def position_bar(x, columns=31):
    cells = ['-'] * columns
    if x is not None and math.isfinite(x) and 0 <= x <= 1:
        cells[round(x * (columns - 1))] = '1'
    return '[' + ''.join(cells) + ']'


def select_detection(boxes, width, height, min_confidence):
    """xyxy는 원본 영상 픽셀 좌표이며, 신뢰도가 가장 높은 상자를 선택합니다."""
    candidates = []
    if boxes is not None:
        for coords, confidence in zip(boxes.xyxy.tolist(), boxes.conf.tolist()):
            if len(coords) != 4 or not all(math.isfinite(float(value)) for value in coords):
                continue
            confidence = float(confidence)
            if not math.isfinite(confidence) or not min_confidence <= confidence <= 1:
                continue
            x1, y1, x2, y2 = (float(value) for value in coords)
            x1, x2 = max(0.0, min(width, x1)), max(0.0, min(width, x2))
            y1, y2 = max(0.0, min(height, y1)), max(0.0, min(height, y2))
            if x2 > x1 and y2 > y1:
                candidates.append((confidence, (x1, y1, x2, y2)))
    return (max(candidates, key=lambda item: item[0]) if candidates else None), len(candidates)


def mock_sample(target, elapsed, fixed_x=None, missing=False):
    # 8초 동안 좌→우→좌로 이동하고 1초간 사라집니다. 실제 프레임과 같은 구조입니다.
    phase = elapsed % 9.0
    record = missing_sample(target)
    if missing or (fixed_x is None and phase >= 8):
        return record
    x = fixed_x if fixed_x is not None else (phase / 4 if phase <= 4 else 2 - phase / 4)
    record.update(detected=True, cx_px=x * 640, cy_px=240.0, confidence=1.0)
    return record


def terminal_line(record, matches, mock=False):
    prefix = 'MOCK ' if mock else 'YOLO '
    if not record['detected']:
        return f"{prefix}{record['target']} NOT FOUND {position_bar(None)}"
    x = record['cx_px'] / record['width']
    return (f"{prefix}{record['target']} cx={record['cx_px']:.1f}px cy={record['cy_px']:.1f}px "
            f"frame={record['width']}x{record['height']} x={x:.3f} {position_bar(x)} "
            f"conf={record['confidence']:.2f} matches={matches}")


def draw_position(frame, record, box, cv2):
    height, width = frame.shape[:2]
    # LED 다섯 개의 기준 위치는 왼쪽 끝부터 0, .25, .5, .75, 1입니다.
    for index in range(5):
        x = round(index * (width - 1) / 4)
        cv2.line(frame, (x, 45), (x, height - 1), (90, 90, 90), 1)
        cv2.putText(frame, str(index + 1), (min(x + 3, width - 18), height - 8),
                    cv2.FONT_HERSHEY_SIMPLEX, .45, (255, 255, 255), 1)
    if record['detected']:
        x1, y1, x2, y2 = box
        cv2.rectangle(frame, (round(x1), round(y1)),
                      (min(width - 1, round(x2)), min(height - 1, round(y2))), (0, 255, 0), 2)
        center = (min(width - 1, round(record['cx_px'])), min(height - 1, round(record['cy_px'])))
        cv2.circle(frame, center, 5, (0, 0, 255), -1)
        label = f"{record['target']} center=({record['cx_px']:.1f},{record['cy_px']:.1f})"
        bar = position_bar(record['cx_px'] / width)
    else:
        label, bar = record['target'] + ' NOT FOUND', position_bar(None)
    cv2.putText(frame, label, (10, 20), cv2.FONT_HERSHEY_SIMPLEX, .5, (0, 255, 0), 1)
    cv2.putText(frame, bar, (10, 40), cv2.FONT_HERSHEY_SIMPLEX, .5, (0, 255, 0), 1)


def main():
    args = arguments()
    target = canonical_name(args.target)
    if args.list_classes:
        _model, names = load_model(args.model)
        for index, name in sorted(names.items()):
            print(f'{index}: {name}')
        return
    from common import write_json, handle_termination
    handle_termination()
    camera = None
    cv2 = None
    frames = detections = 0
    width, height = 640, 480
    reason = 'duration'
    write_json('sample', missing_sample(target))
    try:
        if not args.mock:
            import cv2
            from camera_input import CameraInput
            model, names = load_model(args.model)
            target_ids = [index for index, name in names.items() if canonical_name(name) == target]
            if not target_ids:
                raise RuntimeError(f'모델에 {args.target!r} 클래스가 없습니다. --list-classes로 확인하세요.')
            target = names[target_ids[0]]
            camera = CameraInput(args.source, args.camera_index)
            if not args.headless:
                cv2.namedWindow(WINDOW, cv2.WINDOW_NORMAL)
                cv2.resizeWindow(WINDOW, 800, 600)
        started, last_report = time.monotonic(), float('-inf')
        while args.duration == 0 or time.monotonic() - started < args.duration:
            if args.mock:
                record = mock_sample(target, time.monotonic() - started, args.mock_x, args.mock_missing)
                matches, frame, box = int(record['detected']), None, None
            else:
                ok, frame = camera.read()
                source_time = time.time()  # 추론 이전 시각을 끝까지 전달해 지연된 결과를 구분합니다.
                if not ok:
                    if camera.is_file and frames:
                        reason = 'end_of_video'
                        break
                    raise RuntimeError('카메라에서 영상을 받지 못했습니다.')
                height, width = frame.shape[:2]
                result = model.predict(frame, imgsz=args.imgsz, conf=args.conf, classes=target_ids,
                                       device='cpu', verbose=False, save=False)[0]
                chosen, matches = select_detection(result.boxes, width, height, args.conf)
                record = missing_sample(target, width, height, source_time)
                box = None
                if chosen is not None:
                    confidence, box = chosen
                    x1, y1, x2, y2 = box
                    record.update(detected=True, cx_px=(x1 + x2) / 2, cy_px=(y1 + y2) / 2,
                                  confidence=confidence)
            write_json('sample', record)
            frames += 1
            detections += int(record['detected'])
            now = time.monotonic()
            if now - last_report >= .2:
                print(terminal_line(record, matches, args.mock), flush=True)
                last_report = now
            if not args.mock and not args.headless:
                draw_position(frame, record, box, cv2)
                cv2.imshow(WINDOW, frame)
                if cv2.waitKey(1) & 0xff in (ord('q'), ord('Q'), 27):
                    reason = 'key'
                    break
                if cv2.getWindowProperty(WINDOW, cv2.WND_PROP_VISIBLE) < 1:
                    reason = 'window_closed'
                    break
            if args.mock:
                time.sleep(.1)
    except KeyboardInterrupt:
        reason = 'interrupted'
    except Exception:
        reason = 'error'
        raise
    finally:
        # 검출 실패/종료 시에도 새 '미검출' 결과를 남겨 LED가 계속 켜져 있지 않게 합니다.
        try:
            write_json('sample', missing_sample(target, width, height))
        finally:
            try:
                if camera is not None:
                    camera.close()
            finally:
                if cv2 is not None and not args.headless:
                    cv2.destroyAllWindows()
        print(json.dumps({'frames': frames, 'detected_frames': detections, 'mock': args.mock,
                          'exit_reason': reason, 'images_saved': False}), flush=True)


if __name__ == '__main__':
    main()
