"""ROS2 컨테이너: 중심 좌표를 터미널에 표시하고 LED 5개의 PWM 밝기를 계산합니다."""
import argparse
import math
import time

from common import handle_termination, write_json
from position_policy import PositionState, decode_sample, off_command


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--topic', default='/edu/object_position')
    parser.add_argument('--sigma', type=float, default=0.18,
                        help='빛이 퍼지는 폭(화면 너비를 1로 본 값). 기본0.18')
    parser.add_argument('--smooth-seconds', type=float, default=0.12,
                        help='좌표 떨림을 줄이는 시간 상수. 0이면 원래 좌표 사용')
    parser.add_argument('--duration', type=float, default=0)
    args, ros_args = parser.parse_known_args()
    if not math.isfinite(args.duration) or args.duration < 0:
        parser.error('--duration은 0 이상의 유한한 초 값입니다.')
    try:
        state = PositionState(args.sigma, args.smooth_seconds)
    except ValueError as error:
        parser.error(str(error))

    import rclpy
    from rclpy.node import Node
    from rclpy.executors import ExternalShutdownException
    from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy
    from std_msgs.msg import String

    class PositionListener(Node):
        def __init__(self):
            super().__init__('object_position_led5_listener')
            qos = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                             durability=DurabilityPolicy.VOLATILE)
            self.subscription = self.create_subscription(String, args.topic, self.on_message, qos)
            self.timer = self.create_timer(0.05, self.update_output)
            self.last_report = -float('inf')
            self.get_logger().info('Listening for position JSON on ' + args.topic)

        def on_message(self, message):
            now = time.time()
            state.receive(decode_sample(message.data, now), now)
            # 미검출 통보는 다음 타이머를 기다리지 않고 꺼짐 명령을 전달합니다.
            write_json('command', state.command(now))

        def update_output(self):
            now = time.time()
            # 메시지가 끊겨도 촬영 후 1초가 지나면 다섯 밝기는 모두 0이 됩니다.
            write_json('command', state.command(now))
            monotonic_now = time.monotonic()
            if monotonic_now - self.last_report >= 0.2:
                print(state.terminal_line(now), flush=True)
                self.last_report = monotonic_now

    handle_termination()
    write_json('command', off_command(time.time()))
    rclpy.init(args=ros_args)
    node = None
    started = time.monotonic()
    try:
        node = PositionListener()
        while rclpy.ok() and (args.duration == 0 or time.monotonic() - started < args.duration):
            rclpy.spin_once(node, timeout_sec=0.05)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        write_json('command', off_command(time.time()))
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
