"""호스트에서 밝기 5개를 GPIOZero PWMLED에 적용합니다. --mock은 GPIO를 열지 않습니다."""
import argparse
from contextlib import ExitStack
import math
import time
from common import handle_termination, read_json, write_json
from position_policy import finite_number

PINS = [5, 6, 13, 19, 26]  # 왼쪽→오른쪽, 물리 29/31/33/35/37번


def command_levels(record, now, max_age=1.0):
    off = [0.0]*5
    if (not isinstance(record, dict) or type(record.get('schema')) is not int
            or record['schema'] != 1 or not finite_number(now)
            or not finite_number(max_age) or max_age <= 0):
        return off, 'missing_or_invalid'
    stamp = record.get('source_time')
    if not finite_number(stamp):
        return off, 'invalid_timestamp'
    if not -0.2 <= now-stamp <= max_age:
        return off, 'stale'
    if record.get('detected') is not True:
        return off, 'no_target'
    levels = record.get('brightness')
    if not isinstance(levels, list) or len(levels) != 5:
        return off, 'invalid_brightness'
    if any(not finite_number(v) or not 0 <= v <= 1 for v in levels):
        return off, 'invalid_brightness'
    return [float(v) for v in levels], 'fresh'


def main():
    import fcntl
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pins', nargs=5, type=int, default=PINS)
    parser.add_argument('--mock', action='store_true')
    parser.add_argument('--duration', type=float, default=0)
    args = parser.parse_args()
    if len(set(args.pins)) != 5 or any(not 2 <= pin <= 27 for pin in args.pins):
        parser.error('--pins는 서로 다른 BCM 2~27 번호 5개입니다.')
    if not math.isfinite(args.duration) or args.duration < 0:
        parser.error('--duration은 0 이상의 유한한 초 값입니다.')
    handle_termination()
    devices = []
    with ExitStack() as cleanup:
        lock = cleanup.enter_context(open('/tmp/pi-classroom-led-output.lock', 'a'))
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            parser.error('다른 LED 실습을 먼저 종료하세요.')
        if not args.mock:
            from gpiozero import PWMLED
            from gpio_backend import create_header_factory
            factory = create_header_factory()
            cleanup.callback(factory.close)
            for pin in args.pins:
                devices.append(cleanup.enter_context(
                    PWMLED(pin, frequency=100, initial_value=0, pin_factory=factory)))
        print(('MOCK ' if args.mock else '')+'LED5 output ready; BCM left-to-right='+str(args.pins), flush=True)
        started = time.monotonic()
        last_reason = None
        try:
            while args.duration == 0 or time.monotonic()-started < args.duration:
                now = time.time()
                record = read_json('command')
                levels, reason = command_levels(record, now)
                for device, brightness in zip(devices, levels):
                    device.value = brightness  # 0=꺼짐, 1=최대 PWM 듀티
                write_json('applied', {'schema':1, 'brightness':levels, 'mock':args.mock,
                                      'reason':reason, 'applied_time':now})
                if reason != last_reason:
                    print('LED5 '+reason+' PWM='+str([round(v, 3) for v in levels]), flush=True)
                    last_reason = reason
                time.sleep(0.05)
        except KeyboardInterrupt:
            pass
        finally:
            for device in devices:
                device.off()
            write_json('applied', {'schema':1, 'brightness':[0.0]*5, 'mock':args.mock,
                                  'reason':'stopped', 'applied_time':time.time()})


if __name__ == '__main__':
    main()
