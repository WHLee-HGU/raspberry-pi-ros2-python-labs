"""ROS2 컨테이너: YOLO 중심 좌표를 /edu/object_position으로 발행합니다."""
import argparse
import json
import math
import time

from common import handle_termination, read_json
from position_policy import lost_sample, validated_sample


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--topic', default='/edu/object_position')
    parser.add_argument('--duration', type=float, default=0)
    args, ros_args = parser.parse_known_args()
    if not math.isfinite(args.duration) or args.duration < 0:
        parser.error('--duration은 0 이상의 유한한 초 값입니다.')

    import rclpy
    from rclpy.node import Node
    from rclpy.executors import ExternalShutdownException
    from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy
    from std_msgs.msg import String

    class PositionPublisher(Node):
        def __init__(self):
            super().__init__('object_position_publisher')
            # 최신 좌표가 중요하므로 대기열은 1개, 과거 결과를 보관하지 않습니다.
            qos = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                             durability=DurabilityPolicy.VOLATILE)
            self.publisher = self.create_publisher(String, args.topic, qos)
            self.target = 'unknown'
            self.timer = self.create_timer(0.1, self.publish_position)
            self.get_logger().info('Publishing position JSON on ' + args.topic)

        def publish_position(self):
            now = time.time()
            sample = validated_sample(read_json('sample'), now)
            if sample is not None:
                self.target = sample['target']
            else:
                sample = lost_sample(now, self.target)
            message = String()
            # 촬영 시각을 유지해야 카메라/추론이 멈춘 것을 listener가 알아냅니다.
            message.data = json.dumps(sample, ensure_ascii=False, allow_nan=False)
            self.publisher.publish(message)

    handle_termination()
    rclpy.init(args=ros_args)
    node = None
    started = time.monotonic()
    try:
        node = PositionPublisher()
        while rclpy.ok() and (args.duration == 0 or time.monotonic() - started < args.duration):
            rclpy.spin_once(node, timeout_sec=0.1)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
