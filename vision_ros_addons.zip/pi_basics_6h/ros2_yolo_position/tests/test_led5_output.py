"""실제 GPIO를 열지 않고 LED 명령의 신선도와 안전한 OFF 처리를 확인합니다."""
import copy
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from led5_output import command_levels


def command(**changes):
    record = {'schema': 1, 'source_time': 100.0, 'detected': True,
              'x': 0.5, 'brightness': [0, 0.2, 1, 0.2, 0]}
    record.update(changes)
    return record


class CommandLevelsTests(unittest.TestCase):
    def assert_off(self, record, now=100.4):
        levels, reason = command_levels(record, now)
        self.assertEqual(levels, [0.0] * 5)
        self.assertNotEqual(reason, 'fresh')

    def test_fresh_values_are_preserved_without_mutating_input(self):
        record = command()
        original = copy.deepcopy(record)
        levels, reason = command_levels(record, 100.4)
        self.assertEqual(levels, [0.0, 0.2, 1.0, 0.2, 0.0])
        self.assertEqual(reason, 'fresh')
        self.assertTrue(all(type(value) is float for value in levels))
        self.assertIsNot(levels, record['brightness'])
        self.assertEqual(record, original)

    def test_watchdog_uses_original_capture_time(self):
        record = command()
        self.assertEqual(command_levels(record, 100.9)[1], 'fresh')
        self.assert_off(record, 101.01)
        self.assert_off(record, 102.0)
        self.assertEqual(record['source_time'], 100.0)

    def test_missing_target_clears_previously_bright_output(self):
        self.assertEqual(command_levels(command(), 100.1)[0][2], 1)
        self.assert_off(command(detected=False, brightness=[1] * 5), 100.2)
        for value in (None, 0, 1, 'true', 'false'):
            with self.subTest(detected=value):
                self.assert_off(command(detected=value))

    def test_missing_or_wrong_schema_is_off(self):
        for record in (None, [], '', 1, {}, {'schema': 1}):
            with self.subTest(record=record):
                self.assert_off(record)
        for schema in (None, 0, 2, '1', True, 1.0):
            with self.subTest(schema=schema):
                self.assert_off(command(schema=schema))

    def test_invalid_timestamps_do_not_raise_or_light_leds(self):
        for stamp in (None, True, '100', float('nan'), float('inf'),
                      -float('inf'), 10 ** 1000):
            with self.subTest(stamp_type=type(stamp).__name__):
                self.assert_off(command(source_time=stamp))

    def test_timestamp_boundaries_and_future_clock_tolerance(self):
        self.assertEqual(command_levels(command(), 101.0)[1], 'fresh')
        self.assertEqual(command_levels(command(source_time=100.1), 100.0)[1], 'fresh')
        self.assert_off(command(source_time=100.3), 100.0)

    def test_invalid_clock_or_watchdog_setting_is_off(self):
        for now in (None, True, '100', float('nan'), float('inf'), 10 ** 1000):
            with self.subTest(clock_type=type(now).__name__):
                self.assert_off(command(), now)
        for max_age in (None, True, '1', 0, -1, float('nan'), float('inf'), 10 ** 1000):
            with self.subTest(max_age_type=type(max_age).__name__):
                levels, reason = command_levels(command(), 100.4, max_age=max_age)
                self.assertEqual(levels, [0.0] * 5)
                self.assertNotEqual(reason, 'fresh')

    def test_wrong_brightness_length_or_container_is_off(self):
        for values in (None, [], [0] * 4, [0] * 6, '00000', (0, 0, 0, 0, 0)):
            with self.subTest(values=values):
                self.assert_off(command(brightness=values))

    def test_bad_brightness_fails_entire_command_closed(self):
        for value in (None, True, '0.5', -0.01, 1.01, float('nan'),
                      float('inf'), -float('inf'), 10 ** 1000):
            with self.subTest(value_type=type(value).__name__):
                self.assert_off(command(brightness=[1, 1, value, 1, 1]))

    def test_zero_brightness_is_valid_fresh_command(self):
        levels, reason = command_levels(command(brightness=[0] * 5), 100.4)
        self.assertEqual(levels, [0.0] * 5)
        self.assertEqual(reason, 'fresh')


if __name__ == '__main__':
    unittest.main()
