"""GPIO와 ROS 없이 실행하는 좌표·밝기·오래된 입력 검사."""
import json
import math
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from position_policy import (PositionState, decode_sample, gaussian_brightness,
                             lost_sample, position_bar, validated_sample)


def sample(x=0.5, stamp=100.0, **changes):
    value = {'schema': 1, 'target': 'cell phone', 'detected': True,
             'cx_px': x * 640, 'cy_px': 240.0, 'width': 640, 'height': 480,
             'confidence': 0.9, 'source_time': stamp}
    value.update(changes)
    return value


class GaussianTests(unittest.TestCase):
    def test_center_and_symmetry(self):
        values = gaussian_brightness(0.5)
        self.assertEqual(values[2], 1.0)
        self.assertEqual(values, list(reversed(values)))
        self.assertAlmostEqual(values[1], 0.381171386, places=8)
        self.assertLess(values[0], values[1])

    def test_between_leds_two_equal_peaks(self):
        values = gaussian_brightness(0.375)
        self.assertAlmostEqual(values[1], values[2])
        self.assertLess(values[0], values[1])
        self.assertLess(values[3], values[2])
        self.assertLess(values[1], 1.0)

    def test_edges_and_bounds(self):
        self.assertEqual(gaussian_brightness(0)[0], 1.0)
        self.assertEqual(gaussian_brightness(1)[4], 1.0)
        for number in range(101):
            self.assertTrue(all(0 <= v <= 1 for v in gaussian_brightness(number / 100)))
        for value in (None, True, -1, 2, float('nan'), float('inf')):
            self.assertEqual(gaussian_brightness(value), [0] * 5)

    def test_invalid_sigma(self):
        for sigma in (0, -0.1, 2, float('nan'), float('inf'), True):
            with self.assertRaises(ValueError):
                gaussian_brightness(0.5, sigma)

    def test_extremely_narrow_gaussian_stays_finite(self):
        self.assertEqual(gaussian_brightness(0.5, 1e-300), [0, 0, 1, 0, 0])
        self.assertEqual(gaussian_brightness(0.375, 1e-300), [0] * 5)

    def test_ascii_positions(self):
        self.assertEqual(position_bar(0, 7), '[1------]')
        self.assertEqual(position_bar(0.5, 7), '[---1---]')
        self.assertEqual(position_bar(1, 7), '[------1]')
        self.assertEqual(position_bar(None, 7), '[-------]')


class SampleTests(unittest.TestCase):
    def test_valid_roundtrip(self):
        source = sample()
        self.assertEqual(decode_sample(json.dumps(source), 100.4), source)
        self.assertEqual(validated_sample(lost_sample(100), 100.4)['detected'], False)

    def test_stale_future_and_bad_time(self):
        self.assertIsNone(validated_sample(sample(), 101.01))
        self.assertIsNone(validated_sample(sample(stamp=101), 100))
        for timestamp in (True, '100', float('inf'), float('nan')):
            self.assertIsNone(validated_sample(sample(source_time=timestamp), 100))

    def test_bad_values_are_not_coerced(self):
        cases = [{'schema': True}, {'detected': 1}, {'cx_px': True}, {'cx_px': -1},
                 {'cx_px': 641}, {'cy_px': 481}, {'width': 0}, {'width': 640.0},
                 {'height': True}, {'confidence': 1.1}, {'confidence': float('nan')},
                 {'target': '\x1b[31m'}, {'target': ''}]
        for fields in cases:
            with self.subTest(fields=fields):
                self.assertIsNone(validated_sample(sample(**fields), 100))
        self.assertIsNone(decode_sample('{bad}', 100))
        self.assertIsNone(decode_sample('x' * 8193, 100))
        self.assertIsNone(validated_sample(sample(detected=False), 100))

    def test_huge_json_number_and_invalid_clock_are_rejected(self):
        self.assertIsNone(decode_sample(json.dumps(sample(cx_px=10 ** 1000)), 100))
        self.assertIsNone(validated_sample(sample(), float('nan')))
        self.assertIsNone(validated_sample(sample(), True))


class StateTests(unittest.TestCase):
    def test_ema_only_new_frames_and_no_timestamp_refresh(self):
        state = PositionState(smooth_seconds=0.1)
        state.receive(sample(0), 100)
        state.receive(sample(1, 100.1), 100.1)
        expected = 1 - math.exp(-1)
        self.assertAlmostEqual(state.x, expected)
        state.receive(sample(1, 100.1), 100.2)
        self.assertAlmostEqual(state.x, expected)
        self.assertEqual(state.command(100.9)['source_time'], 100.1)
        state.receive(sample(0, 100.05), 100.2)
        self.assertAlmostEqual(state.x, expected)

    def test_no_detection_and_timeout_switch_off(self):
        state = PositionState()
        state.receive(sample(), 100)
        state.receive(lost_sample(100.1, 'cell phone'), 100.1)
        self.assertEqual(state.command(100.1)['brightness'], [0] * 5)
        state.receive(sample(1, 100.2), 100.2)
        self.assertEqual(state.x, 1)
        self.assertEqual(state.command(101.3)['brightness'], [0] * 5)
        self.assertIsNone(state.sample)

    def test_target_change_and_disabled_smoothing(self):
        state = PositionState()
        state.receive(sample(0), 100)
        state.receive(sample(1, 100.1, target='bottle'), 100.1)
        self.assertEqual(state.x, 1)
        state = PositionState(smooth_seconds=0)
        state.receive(sample(0), 100)
        state.receive(sample(1, 100.1), 100.1)
        self.assertEqual(state.x, 1)

    def test_terminal_uses_raw_coordinate(self):
        state = PositionState(smooth_seconds=0)
        state.receive(sample(), 100)
        text = state.terminal_line(100.1)
        self.assertIn('cx=320.0px cy=240.0px frame=640x480 x=0.500', text)
        self.assertIn('[---------------1---------------]', text)
        self.assertIn('PWM=[0.02 0.38 1.00 0.38 0.02]', text)
        self.assertIn('LOST/OFF', state.terminal_line(102))


if __name__ == '__main__':
    unittest.main()
