YOLO + ROS2: 물체의 위치를 따라 빛나는 LED 5개
============================================================

1. 이 실습에서 만드는 것

카메라가 스마트폰을 찾으면 상자의 중앙 위치를 ROS2로 전달합니다.
수신 노드는 물체의 좌우 위치에 맞춰 LED 5개의 밝기를 계산합니다.
물체와 가장 가까운 LED가 밝아지고, 주변 LED도 부드럽게 켜집니다.
터미널에는 중앙 좌표, 텍스트 위치 막대, LED 밝기가 함께 표시됩니다.

기본 인식 대상은 스마트폰입니다. 모델의 영문 이름은 "cell phone"입니다.
같은 종류의 물체가 여러 개면 신뢰도가 가장 높은 하나를 선택합니다.
물체를 계속 추적하여 같은 개체임을 보장하는 기능은 없으므로,
처음에는 카메라 안에 실습 대상 물체 하나만 두세요.

2. 예제 넣기와 준비 상태 확인

배포받은 yolo_position_led5.zip을 라즈베리파이의 홈 폴더에 넣습니다.
Pi OS 터미널에서 다음 명령을 실행합니다.

    unzip -o ~/yolo_position_led5.zip -d ~
    cd ~/pi_basics_6h/ros2_yolo_position
    bash ../classroom.sh check

이 압축 파일에는 pi_basics_6h/ros2_yolo_position 폴더가 들어 있습니다.
동일 이름의 새 예제 파일을 덮어씁니다. 기존 OS, 가상환경, Docker,
카메라 설정, YOLO 모델을 다시 설치하는 절차는 포함하지 않습니다.
기존 교육용 SD 카드의 YOLO 환경과 pi-class 컨테이너를 이용합니다.

check 결과에서 ROS_DISTRO=humble, ROS imports OK를 확인합니다.
교육용 ROS_DOMAIN_ID는 보통 10 + 조 번호입니다. 예: 4조는 14.
이미 만들어진 pi-class 컨테이너는 기존 도메인을 유지합니다.
classroom.sh start에 다른 숫자를 적는 것만으로 바뀌지는 않습니다.
이번 예제의 publisher와 listener는 같은 컨테이너 환경을 이용합니다.

3. LED 배선

배선을 바꾸기 전에는 정상 종료 후 USB-C 전원을 분리합니다.
LED 5개를 왼쪽에서 오른쪽으로 나란히 놓습니다.
밝기를 비교하기 쉽게 같은 색상의 LED 5개를 권장합니다.

    위치        코드에서 쓰는 BCM 번호     보드 물리 핀 번호
    LED 1       GPIO5                     29
    LED 2       GPIO6                     31
    LED 3       GPIO13                    33
    LED 4       GPIO19                    35
    LED 5       GPIO26                    37
    공통 GND    GND                       39 또는 6

각 LED에는 330Ω 저항을 하나씩 연결합니다. 저항 1개를 공유하지 않습니다.

    GPIO5  ── 330Ω ── LED 1 긴 다리(+) / 짧은 다리(-) ── GND
    GPIO6  ── 330Ω ── LED 2 긴 다리(+) / 짧은 다리(-) ── GND
    GPIO13 ── 330Ω ── LED 3 긴 다리(+) / 짧은 다리(-) ── GND
    GPIO19 ── 330Ω ── LED 4 긴 다리(+) / 짧은 다리(-) ── GND
    GPIO26 ── 330Ω ── LED 5 긴 다리(+) / 짧은 다리(-) ── GND

브레드보드의 공통 GND 레일과 파이 GND 핀을 연결합니다.
레일이 중간에서 끊어진 빵판은 연결 상태를 확인하세요.
LED 회로를 5V 핀에 연결하지 마세요.
LED의 다리 길이가 같다면 부품의 극성 표시를 확인합니다.

GPIO6, 13, 19는 이전 가위바위보 실습과 겹칩니다.
이전 LED 프로그램을 종료하고 핀을 점유하는 다른 프로그램도 닫습니다.
이번 예제는 gpiozero/lgpio의 100Hz 소프트웨어 PWM을 사용합니다.
따라서 하드웨어 PWM 전용 핀 5개가 필요한 것은 아닙니다.

4. 실행: Pi OS 터미널 창 3개

아래 명령은 Docker 안의 셸이 아니라 Pi OS 터미널에서 입력합니다.
세 창 모두 같은 예제 폴더로 이동합니다.

터미널 1 — 카메라/YOLO와 실제 LED 입출력

    cd ~/pi_basics_6h/ros2_yolo_position
    bash run.sh io --target "cell phone"

터미널 2 — ROS2 publisher

    cd ~/pi_basics_6h/ros2_yolo_position
    bash run.sh pub

터미널 3 — ROS2 listener와 밝기 계산

    cd ~/pi_basics_6h/ros2_yolo_position
    bash run.sh sub

스마트폰 전체가 카메라 안에 보이게 한 뒤 좌우로 천천히 움직입니다.
LED 1은 카메라 영상의 왼쪽, LED 5는 오른쪽에 대응합니다.
자신의 몸 기준 왼쪽/오른쪽과 영상의 방향을 혼동하지 않도록 합니다.
원본 카메라 좌표를 이용하며 좌우 반전된 셀카 화면을 기준으로 하지 않습니다.

종료: 카메라 창에서 Q 또는 각 터미널에서 Ctrl+C를 누릅니다.
수업을 끝낼 때는 세 터미널의 프로그램을 모두 종료하세요.
종료와 출력 갱신 중단을 처리하는 LED 소등 기능이 포함되어 있습니다.

5. 배선 없이 먼저 확인하기

카메라와 GPIO를 전혀 사용하지 않는 모의 실행입니다.
터미널 1에서 실제 실행 대신 다음 명령을 사용합니다.
터미널 2와 3은 위의 pub, sub 명령을 그대로 실행합니다.

    bash run.sh io --mock

물체를 중앙에 고정한 모의 데이터로 확인하려면:

    bash run.sh io --mock --mock-x 0.5

실제 카메라 인식은 확인하되 LED 배선은 아직 하지 않았다면:

    bash run.sh io --mock-leds --target "cell phone"

모의 실행 성공은 실제 카메라 또는 LED 배선의 성공을 뜻하지 않습니다.
배선 후에는 실제 io 실행으로 확인하세요.

6. 인식 대상과 카메라 바꾸기

    bash run.sh io --target "bottle"
    bash run.sh io --target "cup"
    bash run.sh io --target "cell phone" --camera-index 0

대상 이름은 사용한 YOLO 모델이 학습한 클래스 이름이어야 합니다.
아무 물건 이름이나 입력한다고 새 물체를 인식하게 되지는 않습니다.
스마트폰의 공식 클래스 이름은 "cell phone"입니다.
이 예제는 phone/smartphone 별칭도 cell phone으로 바꿔 처리합니다.
모델이 인식할 수 있는 전체 목록은 다음 명령으로 확인합니다.

    ../.venv-yolo/bin/python vision_position.py --list-classes

카메라 번호는 다음 목록에서 확인합니다.

    rpicam-hello --list-cameras

--camera-index 0은 소프트웨어 카메라 목록의 0번입니다.
보드의 CAM/DISP0, CAM/DISP1이라는 물리 포트 번호와는 다릅니다.
CAM/DISP1에 한 대만 연결해도 목록의 0번일 수 있습니다.
이 예제는 카메라 드라이버/부팅 설정을 자동 변경하지 않습니다.

LED 핀을 바꾸는 경우 왼쪽부터 BCM 번호를 입력합니다.

    bash run.sh io --target "cell phone" --pins 5 6 13 19 26

7. 터미널 표시 읽기

YOLO가 반환하는 상자 모서리 좌표를 x1, y1, x2, y2라고 하면:

    cx = (x1 + x2) / 2
    cy = (y1 + y2) / 2
    u = cx / 영상의 가로 픽셀 수

cx, cy는 영상 기준 픽셀 좌표입니다.
u는 해상도와 관계없이 0(왼쪽)부터 1(오른쪽)로 표현한 좌표입니다.
640픽셀 영상에서 cx=320이면 u=0.5, 즉 중앙입니다.

31칸짜리 텍스트 막대에서 1은 물체의 좌우 위치를 나타냅니다.
중앙 위치의 예시는 다음과 같습니다.

    [---------------1---------------]

출력에는 cx/cy, 영상 크기, 정규화 좌표, 제어에 쓰는 평활화 좌표,
LED 5개의 PWM 밝기 값도 포함됩니다.
물체가 보이지 않으면 마지막 위치를 유지하지 않고 LED를 끕니다.
새 데이터가 1초 넘게 들어오지 않아도 LED를 끕니다.

8. 가우시안 밝기와 부드러운 움직임

LED의 기준 위치는 다음과 같습니다.

    p = [0.00, 0.25, 0.50, 0.75, 1.00]

각 LED 밝기는 위치와의 거리가 멀수록 작아집니다.

    밝기[i] = exp(-0.5 * ((u - p[i]) / sigma) ** 2)

밝기는 0(꺼짐)부터 1(최대) 사이입니다. 기본 sigma는 0.18입니다.
u=0.50이면 약 [0.021, 0.381, 1.000, 0.381, 0.021]입니다.
u=0.375이면 약 [0.114, 0.786, 0.786, 0.114, 0.002]입니다.
즉 LED 사이에 물체가 있으면 인접한 두 LED가 비슷한 밝기로 켜집니다.
5개 구역을 단순히 켜고 끄는 방식이 아니라 PWM 듀티를 연속적으로 바꿉니다.
실제 눈에 보이는 밝기는 LED 종류와 사람의 시각 특성에도 영향을 받습니다.

불빛의 퍼짐 정도는 listener를 종료한 후 옵션을 바꿔 다시 실행합니다.

    bash run.sh sub --sigma 0.12
    bash run.sh sub --sigma 0.25

0.12는 좁게, 0.25는 넓게 퍼집니다.
좌표 흔들림을 줄이기 위해 기본 0.12초의 EMA 평활화를 적용합니다.
그래서 원래 인식 좌표와 LED 제어 좌표가 잠시 다를 수 있습니다.
평활화를 끄고 비교하려면:

    bash run.sh sub --smooth-seconds 0

9. ROS2와 Python 코드의 역할

    카메라 → YOLO → 좌표 JSON → ROS2 publisher
             → /edu/object_position → ROS2 listener
             → 밝기 JSON → GPIO → LED 5개

YOLO는 Pi OS의 .venv-yolo에서, GPIO는 Pi OS의 시스템 Python에서
실행합니다. ROS2 Python 노드 두 개는 기존 pi-class 컨테이너의
Ubuntu/ROS2 Humble 환경에서 실행합니다. run.sh가 실행 위치를 정합니다.
따라서 사용자가 매번 Docker 진입과 ROS 환경 설정을 할 필요가 없습니다.
공유 폴더의 작은 JSON 파일로 호스트와 컨테이너를 연결하고,
publisher와 listener 사이에서는 실제 ROS2 토픽으로 통신합니다.
카메라 영상 자체는 이 ROS 토픽으로 전송하거나 저장하지 않습니다.

토픽: /edu/object_position
메시지 타입: std_msgs/msg/String
String 안에 다음 항목을 JSON 형식으로 담습니다.

    schema       메시지 구조 식별자
    target       대상 클래스 이름
    detected     이번 프레임에서 발견했는지
    cx_px, cy_px  물체 중앙의 픽셀 좌표
    width, height 영상의 크기
    confidence   인식 신뢰도
    source_time  실제 입력 데이터가 만들어진 시간

String + JSON은 새 ROS 메시지 패키지를 빌드하지 않고 실습하기 위한
구성입니다. 일반 String 자체가 좌표나 단위를 정해 주는 것은 아니므로,
위의 필드 이름과 의미를 publisher/listener가 함께 지켜야 합니다.
publisher는 초당 10회, listener의 제어 주기는 초당 20회입니다.
오래된 입력은 새 전송 시각으로 포장하지 않고 원래 source_time으로
판단하므로, 카메라가 멈추었을 때 마지막 LED가 계속 켜지지 않습니다.

코드를 읽거나 바꿀 때는 다음 파일부터 확인합니다.

    vision_position.py     select_detection(): 검출 상자 중 하나 선택, 중심 좌표 생성
    position_publisher.py  publish_position(): 좌표를 ROS2 토픽으로 발행
    position_listener.py   on_message(): 수신, update_output(): 표시와 제어 갱신
    position_policy.py     gaussian_brightness(): LED 5개 밝기를 계산하는 핵심 함수
    led5_output.py         device.value = brightness: 계산값을 실제 PWM에 적용
    run.sh / io_session.py 필요한 Python 환경과 보조 프로그램을 함께 실행

가장 먼저 읽을 핵심 계산은 아래와 같습니다. center는 각 LED의 위치입니다.

    distance = abs(x - center) / sigma
    brightness = math.exp(-0.5 * distance * distance)

이 계산을 다섯 LED 각각에 적용합니다. x를 왼쪽에서 오른쪽으로 바꾸면
밝기의 봉우리가 LED 1에서 LED 5 쪽으로 이동합니다.

10. 확인할 점과 짧은 탐구 과제

• LED가 모두 꺼짐: 먼저 터미널의 detected 상태와 대상 이름을 확인합니다.
  물체가 인식되는데도 꺼져 있으면 저항, LED 극성, 공통 GND, BCM 번호와
  물리 핀 번호, 이전 프로그램의 핀 점유 여부를 확인합니다.
• 카메라가 열리지 않음: 이전 미리보기/카메라 프로그램을 종료하고
  rpicam-hello --list-cameras에서 번호를 확인합니다.
• 스마트폰 인식이 불안정함: 충분히 밝은 곳에서 전체 윤곽이 보이도록
  거리와 각도를 바꾸거나 bottle/cup 등 다른 학습된 물체로 비교합니다.
• 실행 파일이 없다는 오류: 현재 위치가 ~/pi_basics_6h/ros2_yolo_position
  인지 확인합니다. 압축 파일 내부 폴더 전체를 함께 배포해야 합니다.

과제 A. u=0, 0.25, 0.5, 0.75, 1일 때 가장 밝을 LED를 먼저 예상합니다.
과제 B. sigma를 바꾸고 주변 LED가 켜지는 범위가 어떻게 달라지는지 봅니다.
과제 C. 평활화 0과 0.12를 비교하여 흔들림과 반응 속도의 차이를 설명합니다.

참고 문서
Ultralytics 예측 결과와 상자 좌표:
https://docs.ultralytics.com/modes/predict/
GPIOZero PWMLED:
https://gpiozero.readthedocs.io/en/stable/api_output.html#pwmled
ROS2 Humble String 메시지:
https://docs.ros.org/en/humble/p/std_msgs/msg/String.html
