#!/usr/bin/env bash
# Pi OS 터미널용. YOLO/GPIO는 호스트, ROS2 노드는 기존 pi-class 컨테이너.
set -euo pipefail
lab_dir="$(cd "$(dirname "$0")" && pwd)"
project_dir="$(dirname "$lab_dir")"
# 컨테이너보다 먼저 student가 공유 폴더를 만들어 어느 실행 순서에서도 기록 가능.
mkdir -p "$lab_dir/data"
action="${1:-help}"
if (($#)); then shift; fi
case "$action" in
  io) exec /usr/bin/python3 "$lab_dir/io_session.py" "$@" ;;
  pub) node=position_publisher.py ;;
  sub) node=position_listener.py ;;
  *)
    echo '각 Pi OS 터미널에서 bash run.sh io / pub / sub'
    echo 'io --target "cell phone" : 실제 카메라·LED'
    echo 'io --mock : 카메라·GPIO 없이 전체 흐름 확인'
    echo 'io --mock-leds : 실제 카메라, GPIO 출력 모의 실행'
    echo 'sub --sigma 0.18 --smooth-seconds 0.12'
    exit 0 ;;
esac
sudo docker inspect pi-class --format '{{range .Mounts}}{{if eq .Destination "/work"}}{{.Source}}{{end}}{{end}}' |
  /usr/bin/python3 -c 'import pathlib,sys; expected=pathlib.Path(sys.argv[1]).resolve(); actual=sys.stdin.read().strip(); assert actual and pathlib.Path(actual).resolve()==expected,"pi-class의 /work 공유 폴더가 이 교육 폴더와 다릅니다."' "$project_dir"
sudo docker start pi-class >/dev/null
terminal_options=(-i)
if [[ -t 0 && -t 1 ]]; then terminal_options=(-it); fi
exec sudo docker exec "${terminal_options[@]}" -e PYTHONUNBUFFERED=1 pi-class bash -c \
  'source /opt/ros/humble/setup.bash; exec python3 "/work/ros2_yolo_position/$1" "${@:2}"' bash "$node" "$@"
