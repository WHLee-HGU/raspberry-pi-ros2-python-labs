"""한 터미널에서 YOLO 입력과 LED 출력 도우미를 실행하고 함께 정리합니다."""
import argparse
import math
from pathlib import Path
import signal
import subprocess
import sys
import time
from common import handle_termination, write_json
from position_policy import lost_sample


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', default='cell phone')
    parser.add_argument('--pins', nargs=5, type=int, default=[5, 6, 13, 19, 26])
    parser.add_argument('--mock', action='store_true', help='카메라와 GPIO 모두 모의 실행')
    parser.add_argument('--mock-leds', action='store_true', help='실제 YOLO 입력, GPIO 출력은 모의 실행')
    parser.add_argument('--mock-x', type=float)
    parser.add_argument('--mock-missing', action='store_true')
    parser.add_argument('--headless', action='store_true')
    parser.add_argument('--duration', type=float, default=0)
    parser.add_argument('--camera-index', type=int, default=0)
    parser.add_argument('--source', default='picamera2')
    parser.add_argument('--conf', type=float, default=0.4)
    parser.add_argument('--imgsz', type=int, default=320)
    parser.add_argument('--model', type=Path)
    args = parser.parse_args()
    if not math.isfinite(args.duration) or args.duration < 0:
        parser.error('--duration은 0 이상인 초 값입니다.')
    if not math.isfinite(args.conf) or not 0 < args.conf <= 1:
        parser.error('--conf는 0보다 크고 1 이하입니다.')
    if args.camera_index < 0 or args.imgsz < 32 or args.imgsz % 32:
        parser.error('카메라 번호는 0 이상, imgsz는 32의 양의 배수입니다.')
    if len(set(args.pins)) != 5 or any(not 2 <= p <= 27 for p in args.pins):
        parser.error('--pins는 서로 다른 BCM 2~27 번호 5개입니다.')
    if args.mock_x is not None and (not math.isfinite(args.mock_x) or not 0 <= args.mock_x <= 1):
        parser.error('--mock-x는 0~1 사이입니다.')
    if not args.mock and (args.mock_x is not None or args.mock_missing):
        parser.error('--mock-x와 --mock-missing은 --mock과 함께 사용합니다.')
    if args.mock_x is not None and args.mock_missing:
        parser.error('--mock-x와 --mock-missing 중 하나만 사용하세요.')
    if not args.target.strip() or not args.source.strip():
        parser.error('target/source를 비워 둘 수 없습니다.')
    here = Path(__file__).resolve().parent
    interpreter = Path(sys.executable) if args.mock else here.parent/'.venv-yolo/bin/python'
    if not interpreter.is_file():
        parser.error('기존 YOLO 가상환경을 찾지 못했습니다: '+str(interpreter))
    producer = [str(interpreter), '-u', str(here/'vision_position.py'),
                '--target', args.target, '--source', args.source, '--camera-index', str(args.camera_index),
                '--conf', str(args.conf), '--imgsz', str(args.imgsz)]
    if args.mock:
        producer += ['--mock']
    if args.mock_x is not None:
        producer += ['--mock-x', str(args.mock_x)]
    if args.mock_missing:
        producer += ['--mock-missing']
    if args.headless:
        producer += ['--headless']
    if args.model is not None:
        producer += ['--model', str(args.model)]
    output = ['/usr/bin/python3', '-u', str(here/'led5_output.py'),
              '--pins', *map(str, args.pins)]
    if args.mock or args.mock_leds:
        output += ['--mock']
    processes = []
    handle_termination()
    # 이전 실행의 밝기가 잠깐 재적용되지 않도록 새 출력은 OFF에서 시작합니다.
    write_json('sample', lost_sample(time.time(), args.target))
    write_json('command', {'schema':1, 'source_time':time.time(), 'detected':False,
                           'x':None, 'brightness':[0.0]*5})
    try:
        processes.append(subprocess.Popen(output, start_new_session=True))
        time.sleep(0.3)
        if processes[0].poll() is not None:
            raise RuntimeError('LED 출력 도우미를 시작하지 못했습니다.')
        processes.append(subprocess.Popen(producer, start_new_session=True))
        print('다른 두 터미널에서 bash run.sh pub / bash run.sh sub를 실행하세요.', flush=True)
        print('카메라='+('MOCK' if args.mock else 'REAL')+
              ' GPIO='+('MOCK' if args.mock or args.mock_leds else 'REAL'), flush=True)
        started = time.monotonic()
        while args.duration == 0 or time.monotonic()-started < args.duration:
            if processes[0].poll() is not None:
                raise RuntimeError('LED 출력 도우미가 중단되었습니다.')
            state = processes[1].poll()
            if state is not None:
                if state == 0:
                    print('카메라 입력이 종료되어 LED 출력도 정리합니다.', flush=True)
                    break
                raise RuntimeError(f'YOLO 입력 도우미가 종료되었습니다: {state}')
            time.sleep(0.1)
    except KeyboardInterrupt:
        pass
    finally:
        for process in reversed(processes):
            if process.poll() is None:
                process.send_signal(signal.SIGINT)
        for process in reversed(processes):
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.terminate()
                try:
                    process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
        write_json('command', {'schema':1, 'source_time':time.time(), 'detected':False,
                               'x':None, 'brightness':[0.0]*5})


if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError) as error:
        raise SystemExit(str(error))
