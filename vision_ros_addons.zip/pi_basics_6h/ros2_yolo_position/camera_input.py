"""CSI/USB/동영상 입력을 OpenCV의 BGR 영상으로 전달합니다. 저장 기능은 없습니다."""
from pathlib import Path
import time


class CameraInput:
    def __init__(self, source='picamera2', camera_index=0):
        self.picam = self.capture = None
        self.started = False
        self.is_file = False
        try:
            if source == 'picamera2':
                from picamera2 import Picamera2
                from libcamera import controls
                cameras = Picamera2.global_camera_info()
                if not any(item['Num'] == camera_index for item in cameras):
                    raise RuntimeError('카메라 번호가 없습니다. rpicam-hello --list-cameras로 확인하세요.')
                self.picam = Picamera2(camera_index)
                configuration = self.picam.create_video_configuration(
                    main={'size': (640, 480), 'format': 'RGB888'}, buffer_count=4)
                self.picam.configure(configuration)
                if 'AfMode' in self.picam.camera_controls:
                    self.picam.set_controls({'AfMode': controls.AfModeEnum.Continuous})
                self.picam.start()
                self.started = True
                time.sleep(0.5)
                print(f'CSI camera index={camera_index} (software list index)', flush=True)
            else:
                import cv2
                value = int(source) if source.isdecimal() else str(Path(source).expanduser())
                self.is_file = not source.isdecimal()
                if self.is_file and not Path(value).is_file():
                    raise RuntimeError('입력 동영상 파일을 찾지 못했습니다: ' + str(value))
                self.capture = cv2.VideoCapture(value)
                if not self.is_file:
                    self.capture.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
                    self.capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
                if not self.capture.isOpened():
                    raise RuntimeError('USB 카메라 또는 동영상 파일을 열지 못했습니다.')
        except BaseException:
            self.close()
            raise

    def read(self):
        if self.picam is not None:
            # Picamera2 RGB888 배열의 메모리 순서는 BGR: OpenCV/YOLO에 바로 사용합니다.
            return True, self.picam.capture_array('main')
        return self.capture.read()

    def close(self):
        if self.picam is not None:
            try:
                if self.started:
                    self.picam.stop()
            finally:
                self.picam.close()
                self.picam = None
        if self.capture is not None:
            self.capture.release()
            self.capture = None
