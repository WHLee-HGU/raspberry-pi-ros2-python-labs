"""카메라·ROS·GPIO 없이 읽고 시험할 수 있는 위치/밝기 계산입니다."""
import json
import math

LED_CENTERS = (0.0, 0.25, 0.5, 0.75, 1.0)
MAX_AGE = 1.0


def finite_number(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:  # JSON의 과도하게 큰 정수도 유효한 좌표가 아닙니다.
        return False


def lost_sample(now, target='unknown'):
    """물체를 찾지 못했음을 명시합니다. 이전 위치를 재사용하지 않습니다."""
    return {'schema': 1, 'target': target, 'detected': False,
            'cx_px': None, 'cy_px': None, 'width': 0, 'height': 0,
            'confidence': 0.0, 'source_time': float(now)}


def validated_sample(record, now, max_age=MAX_AGE):
    """정상이며 최근에 촬영된 결과만 새 dict로 반환합니다."""
    if not finite_number(now) or not finite_number(max_age) or max_age <= 0:
        return None
    if not isinstance(record, dict) or type(record.get('schema')) is not int or record['schema'] != 1:
        return None
    target, detected = record.get('target'), record.get('detected')
    if (not isinstance(target, str) or not 1 <= len(target) <= 100
            or not target.isprintable() or type(detected) is not bool):
        return None
    stamp, confidence = record.get('source_time'), record.get('confidence')
    if not finite_number(stamp) or not -0.2 <= now - stamp <= max_age:
        return None
    if not finite_number(confidence) or not 0 <= confidence <= 1:
        return None
    width, height = record.get('width'), record.get('height')
    if (type(width) is not int or type(height) is not int
            or not 0 <= width <= 16384 or not 0 <= height <= 16384):
        return None
    cx, cy = record.get('cx_px'), record.get('cy_px')
    if detected:
        if (width == 0 or height == 0 or not finite_number(cx) or not finite_number(cy)
                or not 0 <= cx <= width or not 0 <= cy <= height):
            return None
        cx, cy = float(cx), float(cy)
    elif cx is not None or cy is not None:
        return None
    return {'schema': 1, 'target': target, 'detected': detected,
            'cx_px': cx, 'cy_px': cy, 'width': width, 'height': height,
            'confidence': float(confidence), 'source_time': float(stamp)}


def decode_sample(text, now):
    if not isinstance(text, str) or len(text) > 8192:
        return None
    try:
        return validated_sample(json.loads(text), now)
    except (ValueError, TypeError, RecursionError):
        return None


def gaussian_brightness(x, sigma=0.18):
    """x는 화면 왼쪽0~오른쪽1. 각 LED 중심에서 멀수록 밝기가 줄어듭니다."""
    if not finite_number(sigma) or not 0 < sigma <= 1:
        raise ValueError('sigma는 0보다 크고 1 이하인 유한한 숫자입니다.')
    if not finite_number(x) or not 0 <= x <= 1:
        return [0.0] * 5
    # 가장 가까운 LED만 고르는 대신 다섯 LED 모두의 거리를 계산합니다.
    levels = []
    for center in LED_CENTERS:
        distance = abs(x - center) / sigma
        # 극단적으로 작은 sigma도 제곱 오버플로 없이 계산합니다.
        levels.append(0.0 if distance > 40 else math.exp(-0.5 * distance * distance))
    return levels


def position_bar(x, columns=31):
    if type(columns) is not int or not 2 <= columns <= 201:
        raise ValueError('columns는 2~201 정수입니다.')
    cells = ['-'] * columns
    if finite_number(x) and 0 <= x <= 1:
        cells[int(x * (columns - 1) + 0.5)] = '1'
    return '[' + ''.join(cells) + ']'


def off_command(now):
    return {'schema': 1, 'source_time': float(now), 'detected': False,
            'x': None, 'brightness': [0.0] * 5}


class PositionState:
    """새 프레임에만 EMA를 적용하며 미검출·오래된 입력은 즉시 초기화합니다."""
    def __init__(self, sigma=0.18, smooth_seconds=0.12):
        gaussian_brightness(0.5, sigma)  # 설정값 검증
        if not finite_number(smooth_seconds) or smooth_seconds < 0:
            raise ValueError('smooth-seconds는 0 이상의 유한한 숫자입니다.')
        self.sigma, self.smooth_seconds = sigma, smooth_seconds
        self.sample, self.x = None, None
        self.last_target = 'unknown'

    def reset(self):
        self.sample, self.x = None, None

    def receive(self, record, now):
        sample = validated_sample(record, now)
        if sample is None or not sample['detected']:
            if sample is not None:
                self.last_target = sample['target']
            self.reset()
            return
        # 재전송·순서가 뒤바뀐 프레임을 새 관측으로 처리하지 않습니다.
        if self.sample is not None and sample['source_time'] <= self.sample['source_time']:
            return
        raw_x = sample['cx_px'] / sample['width']
        previous = self.sample
        if (previous is None or sample['target'] != previous['target']
                or sample['source_time'] - previous['source_time'] > MAX_AGE
                or self.smooth_seconds == 0):
            self.x = raw_x
        else:
            dt = sample['source_time'] - previous['source_time']
            alpha = -math.expm1(-dt / self.smooth_seconds)
            self.x += alpha * (raw_x - self.x)
        self.sample = sample
        self.last_target = sample['target']

    def command(self, now):
        if self.sample is None or validated_sample(self.sample, now) is None:
            self.reset()
            return off_command(now)
        return {'schema': 1, 'source_time': self.sample['source_time'], 'detected': True,
                'x': self.x, 'brightness': gaussian_brightness(self.x, self.sigma)}

    def terminal_line(self, now):
        command = self.command(now)
        levels = ' '.join(f'{value:.2f}' for value in command['brightness'])
        if not command['detected']:
            return f'{self.last_target}: LOST/OFF {position_bar(None)} PWM=[{levels}]'
        sample = self.sample
        raw_x = sample['cx_px'] / sample['width']
        return (f"{sample['target']}: cx={sample['cx_px']:.1f}px cy={sample['cy_px']:.1f}px "
                f"frame={sample['width']}x{sample['height']} x={raw_x:.3f} "
                f"filtered={self.x:.3f} {position_bar(raw_x)} PWM=[{levels}]")
