#!/usr/bin/env bash
set -euo pipefail
root_dir="$(cd "$(dirname "$0")" && pwd)"
case "${1:-}" in
  start)
    team="${2:-}"
    [[ "$team" =~ ^[0-9]{1,2}$ ]] || { echo 'Team must be 1..30'; exit 2; }
    team_num=$((10#$team))
    ((team_num >= 1 && team_num <= 30)) || { echo 'Team must be 1..30'; exit 2; }
    if sudo docker container inspect pi-class >/dev/null 2>&1; then
      echo 'pi-class already exists; reusing its original team/domain.'
      sudo docker start pi-class >/dev/null
    else
      mkdir -p "$root_dir/data"
      sudo docker run -d --name pi-class --network host \
        -e ROS_DOMAIN_ID=$((10+team_num)) -e ROS_LOCALHOST_ONLY=1 \
        --mount "type=bind,source=$root_dir,target=/work" \
        --workdir /work pi-class:humble sleep infinity >/dev/null
    fi
    echo 'Ready. Open separate terminals and run: bash classroom.sh enter'
    ;;
  enter)
    exec sudo docker exec -it pi-class bash -c \
      'source /opt/ros/humble/setup.bash; exec bash --norc -i'
    ;;
  check)
    sudo docker exec pi-class bash -c \
      'source /opt/ros/humble/setup.bash && echo ROS_DISTRO=$ROS_DISTRO && echo ROS_DOMAIN_ID=$ROS_DOMAIN_ID && python3 -c "import rclpy; from sensor_msgs.msg import Range" && echo "ROS imports OK"'
    ;;
  stop) sudo docker stop pi-class ;;
  *) echo 'Usage: bash classroom.sh {start TEAM|enter|check|stop}'; exit 2 ;;
esac
