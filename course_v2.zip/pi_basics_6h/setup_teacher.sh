#!/usr/bin/env bash
# Run on a NEW teaching SD card, never on the vendor's robot image.
set -euo pipefail
if [[ "${1:-}" != "--teaching-card" ]]; then
  echo 'Usage: bash setup_teacher.sh --teaching-card'; exit 2
fi
source /etc/os-release
[[ "${VERSION_CODENAME:-}" == bookworm ]] || { echo 'Expected Bookworm teaching image'; exit 1; }
[[ "$(dpkg --print-architecture)" == arm64 ]] || { echo 'Expected arm64'; exit 1; }
sudo apt-get update
sudo apt-get install -y python3-gpiozero python3-lgpio python3-venv \
    i2c-tools python3-smbus python3-opencv docker.io git unzip thonny python3-picamera2 rpicam-apps
sudo systemctl enable --now docker
cd "$(dirname "$0")"
sudo docker build -t pi-class:humble .
mkdir -p data
echo 'Build finished. Rehearse all labs on this Pi; record versions before cloning.'
