#!/usr/bin/env bash
# Teacher only. New teaching SD; Raspberry Pi OS Bookworm arm64 / Python 3.11.
set -euo pipefail
[[ "${1:-}" == --teaching-card ]] || { echo 'Use --teaching-card'; exit 2; }
source /etc/os-release
[[ "${VERSION_CODENAME:-}" == bookworm ]] || { echo 'Expected Bookworm'; exit 1; }
[[ "$(dpkg --print-architecture)" == arm64 ]] || { echo 'Expected arm64'; exit 1; }
cd "$(dirname "$0")"
python3 -c 'import sys; assert sys.version_info[:2] == (3,11), sys.version'
sudo apt-get update
sudo apt-get install -y python3-venv python3-opencv libgl1 libglib2.0-0 libportaudio2 python3-picamera2 rpicam-apps
python3 -m venv --system-site-packages .venv-mp
.venv-mp/bin/python -m pip install --upgrade pip
.venv-mp/bin/python -m pip install --only-binary=:all: -r vision/requirements-mediapipe.txt
.venv-mp/bin/python vision/prepare_models.py mediapipe
.venv-mp/bin/python -m pip check
.venv-mp/bin/python -m pip freeze > vision/lock-mediapipe-arm64.txt
python3 -m venv --system-site-packages .venv-yolo
.venv-yolo/bin/python -m pip install --upgrade pip
# CPU wheels avoid downloading CUDA dependencies on a Raspberry Pi.
.venv-yolo/bin/python -m pip install --only-binary=:all: --index-url https://download.pytorch.org/whl/cpu 'torch==2.10.0+cpu' 'torchvision==0.25.0+cpu'
.venv-yolo/bin/python -m pip install --only-binary=:all: -r vision/requirements-yolo.txt
YOLO_AUTOINSTALL=false .venv-yolo/bin/python vision/prepare_models.py yolo
.venv-yolo/bin/python -m pip check
.venv-yolo/bin/python -m pip freeze > vision/lock-yolo-arm64.txt
sha256sum models/hand_landmarker.task models/yolo11n.pt > vision/model-sha256.txt
find models/yolo11n_ncnn_model -type f ! -name '*.pyc' -exec sha256sum {} + >> vision/model-sha256.txt
echo 'Installation finished. Run all three GUI demos and the 10-minute acceptance test.'
