#!/usr/bin/env bash
# Teacher-only orchestration for a NEW teaching SD, not a vendor robot image.
set -euo pipefail
if [[ "${1:-}" != "--teaching-card" || "$#" -ne 1 ]]; then
  printf '%s\n' 'Usage on a new teaching SD: bash prepare_all.sh --teaching-card'
  exit 2
fi
project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$project_dir"
printf '%s\n' '1/2 Host packages and ROS Humble Docker image'
bash setup_teacher.sh --teaching-card
printf '%s\n' '2/2 Separate MediaPipe/YOLO environments and local models'
bash setup_vision.sh --teaching-card
printf '%s\n' 'Installation commands completed. Continue the teacher checklist before cloning.'
printf '%s\n' 'Create the team container with classroom.sh, then check GPIO, camera and offline execution.'
