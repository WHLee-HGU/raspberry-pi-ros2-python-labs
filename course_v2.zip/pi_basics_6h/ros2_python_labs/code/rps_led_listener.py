"""컨테이너: /edu/rps를 받아 빨강/파랑/노랑 LED 명령으로 바꿉니다."""
import argparse
import math
import time
import rclpy
from rclpy.node import Node
from rclpy.executors import ExternalShutdownException
from std_msgs.msg import String
from common import write_command
from rps_policy import GESTURES, fresh_rps, rps_colors
from vision_policy import decode_state


class RpsLedListener(Node):
    def __init__(self):
        super().__init__('rps_led_listener')
        self.gesture, self.source_time = 'UNKNOWN', 0.0
        self.subscription = self.create_subscription(String, '/edu/rps', self.on_message, 10)
        self.timer = self.create_timer(0.1, self.update_led)

    def on_message(self, message):
        gesture, stamp = decode_state(message.data, 'gesture', GESTURES, time.time())
        if gesture != self.gesture:
            self.get_logger().info('gesture=' + gesture)
        self.gesture, self.source_time = gesture, stamp

    def update_led(self):
        now = time.time()
        gesture = fresh_rps(self.gesture, self.source_time, now)
        write_command('rps_led', rps_colors(gesture),
                      source_time=self.source_time if gesture != 'UNKNOWN' else now)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--duration', type=float, default=0)
    args, ros_args = parser.parse_known_args()
    if not math.isfinite(args.duration) or args.duration < 0:
        parser.error('--duration은 0 이상의 유한한 초 값입니다.')
    rclpy.init(args=ros_args)
    node = RpsLedListener()
    started = time.monotonic()
    try:
        while rclpy.ok() and (args.duration == 0 or time.monotonic()-started < args.duration):
            rclpy.spin_once(node, timeout_sec=0.1)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        write_command('rps_led', rps_colors('UNKNOWN'))
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
