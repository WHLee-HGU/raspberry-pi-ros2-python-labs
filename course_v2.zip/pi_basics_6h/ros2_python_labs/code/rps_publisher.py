"""컨테이너: MediaPipe 가위바위보 결과를 /edu/rps 토픽으로 발행합니다."""
import argparse
import math
import time
import rclpy
from rclpy.node import Node
from rclpy.executors import ExternalShutdownException
from std_msgs.msg import String
from common import read_sample
from rps_policy import GESTURES
from vision_policy import encode_state


class RpsPublisher(Node):
    def __init__(self):
        super().__init__('rps_publisher')
        self.publisher = self.create_publisher(String, '/edu/rps', 10)
        self.timer = self.create_timer(0.1, self.publish_rps)

    def publish_rps(self):
        # JSON 파일에는 영상 대신 동작 이름과 촬영 시각만 들어 있습니다.
        sample = read_sample('rps', max_age=1.0)
        message = String()
        message.data = encode_state(sample, 'gesture', GESTURES, time.time())
        self.publisher.publish(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--duration', type=float, default=0)
    args, ros_args = parser.parse_known_args()
    if not math.isfinite(args.duration) or args.duration < 0:
        parser.error('--duration은 0 이상의 유한한 초 값입니다.')
    rclpy.init(args=ros_args)
    node = RpsPublisher()
    started = time.monotonic()
    try:
        while rclpy.ok() and (args.duration == 0 or time.monotonic()-started < args.duration):
            rclpy.spin_once(node, timeout_sec=0.1)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
