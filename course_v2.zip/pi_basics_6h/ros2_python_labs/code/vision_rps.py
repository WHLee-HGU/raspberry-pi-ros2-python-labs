"""호스트 .venv-mp: 카메라의 가위바위보 판정과 촬영 시각을 기록합니다."""
import argparse
import math
from pathlib import Path
import time
from common import handle_termination, write_sample
from rps_policy import GESTURES, StableRps, classify_rps, fresh_rps


def add_camera_arguments(parser):
    parser.add_argument('--source', default='picamera2')
    parser.add_argument('--camera-index', type=int, help='생략하면 물리 CAM/DISP0 자동 선택')
    parser.add_argument('--model', type=Path,
                        default=Path(__file__).resolve().parents[2]/'models/gesture_recognizer.task')
    parser.add_argument('--min-score', type=float, default=0.6)
    parser.add_argument('--stable-frames', type=int, default=3)
    parser.add_argument('--headless', action='store_true')
    parser.add_argument('--duration', type=float, default=0, help='0이면 Ctrl+C까지 실행')
    parser.add_argument('--mock', action='store_true', help='카메라/GPIO 없이 모의 상태 사용')
    parser.add_argument('--mock-state', choices=['CYCLE', *GESTURES], default='CYCLE')


def validate_camera_arguments(parser, args):
    if not math.isfinite(args.duration) or args.duration < 0:
        parser.error('--duration은 0 이상의 유한한 초 값입니다.')
    if args.camera_index is not None and args.camera_index < 0:
        parser.error('--camera-index는 0 이상입니다.')
    if not math.isfinite(args.min_score) or not 0 < args.min_score <= 1:
        parser.error('--min-score는 0보다 크고 1 이하입니다.')
    if args.stable_frames < 1:
        parser.error('--stable-frames는 1 이상입니다.')


def recognized_frames(args):
    """(확정 동작, 촬영 시각)을 전달. 창에는 원래 모델 결과도 표시합니다."""
    camera = detector = None
    try:
        if not args.mock:
            if not args.model.is_file():
                raise RuntimeError('gesture_recognizer.task가 없습니다: ' + str(args.model))
            import cv2
            import mediapipe as mp
            from mediapipe.tasks import python
            from mediapipe.tasks.python import vision
            from vision_camera import CameraFrames
            options = vision.GestureRecognizerOptions(
                base_options=python.BaseOptions(model_asset_path=str(args.model)),
                running_mode=vision.RunningMode.VIDEO, num_hands=2)
            detector = vision.GestureRecognizer.create_from_options(options)
            camera = CameraFrames(args.source, args.camera_index)
        stable = StableRps(args.stable_frames)
        started, last_ms = time.monotonic(), -1
        while args.duration == 0 or time.monotonic()-started < args.duration:
            if args.mock:
                raw = args.mock_state
                if raw == 'CYCLE':
                    raw = GESTURES[int((time.monotonic()-started)/2) % len(GESTURES)]
                source_time, frame, model_name = time.time(), None, 'MOCK'
            else:
                ok, frame = camera.read()
                source_time = time.time()  # 추론 전에 기록해야 처리 지연도 확인할 수 있습니다.
                if not ok:
                    raise RuntimeError('카메라 프레임을 받지 못했습니다.')
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                last_ms = max(last_ms+1, time.monotonic_ns()//1_000_000)
                result = detector.recognize_for_video(
                    mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb), last_ms)
                raw = classify_rps(result.gestures, len(result.hand_landmarks), args.min_score)
                model_name = (result.gestures[0][0].category_name
                              if result.gestures and result.gestures[0] else 'None')
            gesture = fresh_rps(stable.update(raw), source_time, time.time())
            yield gesture, source_time
            if not args.mock and not args.headless:
                cv2.putText(frame, f'{gesture} (model={model_name})', (10, 32),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 255, 0), 2)
                cv2.imshow('RPS - Q to quit', frame)
                if cv2.waitKey(1) & 0xff == ord('q'):
                    break
            if args.mock:
                time.sleep(0.1)
    finally:
        if camera is not None:
            camera.close()
        if detector is not None:
            detector.close()
        if not args.mock and not args.headless:
            import cv2
            cv2.destroyAllWindows()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    add_camera_arguments(parser)
    args = parser.parse_args()
    validate_camera_arguments(parser, args)
    handle_termination()
    write_sample('rps', {'gesture': 'UNKNOWN'})
    previous, frames = None, 0
    stream = recognized_frames(args)
    try:
        for gesture, captured in stream:
            frames += 1
            write_sample('rps', {'gesture': gesture}, source_time=captured)
            if gesture != previous:
                print(('MOCK ' if args.mock else '') + 'rps=' + gesture, flush=True)
                previous = gesture
    except KeyboardInterrupt:
        pass
    finally:
        stream.close()
        write_sample('rps', {'gesture': 'UNKNOWN'})
        print(f'processed_frames={frames} mock={args.mock}', flush=True)


if __name__ == '__main__':
    main()
