"""가위바위보 규칙만 담은 모듈. 카메라·GPIO·ROS 없이 시험할 수 있습니다."""
import math

GESTURES = ('SCISSORS', 'ROCK', 'PAPER', 'UNKNOWN')
MODEL_TO_RPS = {'Victory': 'SCISSORS', 'Closed_Fist': 'ROCK', 'Open_Palm': 'PAPER'}


def classify_rps(categories, hand_count=1, min_score=0.6):
    """손 하나와 충분한 신뢰도가 확인될 때만 공식 모델 결과를 번역합니다."""
    if hand_count != 1 or len(categories) != 1 or not categories[0]:
        return 'UNKNOWN'
    try:
        top = categories[0][0]
        score = float(top.score)
        if not math.isfinite(score) or not min_score <= score <= 1:
            return 'UNKNOWN'
        return MODEL_TO_RPS.get(top.category_name, 'UNKNOWN')
    except (AttributeError, TypeError, ValueError):
        return 'UNKNOWN'


class StableRps:
    """같은 결과가 3프레임 이어져야 확정. 바뀌거나 불명확하면 즉시 꺼짐."""
    def __init__(self, frames=3):
        if isinstance(frames, bool) or not isinstance(frames, int) or frames < 1:
            raise ValueError('frames는 1 이상의 정수입니다.')
        self.frames = frames
        self.candidate = 'UNKNOWN'
        self.count = 0

    def update(self, raw):
        if raw not in GESTURES[:3]:
            self.candidate, self.count = 'UNKNOWN', 0
            return 'UNKNOWN'
        self.count = self.count + 1 if raw == self.candidate else 1
        self.candidate = raw
        return raw if self.count >= self.frames else 'UNKNOWN'


def fresh_rps(gesture, source_time, now, max_age=1.0):
    """촬영 후 1초가 지난 결과는 추론/통신이 멈춘 것으로 보고 끕니다."""
    if gesture not in GESTURES[:3]:
        return 'UNKNOWN'
    if isinstance(source_time, bool) or not isinstance(source_time, (int, float)):
        return 'UNKNOWN'
    if not math.isfinite(source_time) or not math.isfinite(now):
        return 'UNKNOWN'
    return gesture if -0.2 <= now - source_time <= max_age else 'UNKNOWN'


def rps_colors(gesture):
    """가위=빨강, 바위=파랑, 보=노랑. 세 LED 중 최대 하나만 켭니다."""
    return {'red': float(gesture == 'SCISSORS'),
            'blue': float(gesture == 'ROCK'),
            'yellow': float(gesture == 'PAPER')}
