# 라즈베리파이 6시간 두 번째 교육

기존 수업용 Raspberry Pi OS Bookworm 64비트 SD카드를 사용하는 개정판입니다.
수업 시간에는 예제를 실행하고, 조건과 함수를 수정하며 결과를 비교합니다.

## 전반 3시간

1. BCM 핀 번호, 브레드보드, 저항과 LED 방향
2. 버튼 입력으로 LED 켜기: `python3 labs/button_led.py`
3. 밝기 변화와 PWM: `python3 labs/pwm_led.py`
4. 초음파 거리 측정: `python3 labs/distance_read.py`
5. 거리로 밝기 조절 과제: `python3 labs/distance_pwm_assignment.py`

위 명령은 먼저 `cd ~/pi_basics_6h`를 실행한 파이 OS 터미널에서 사용합니다.
완성 예제는 `python3 labs/distance_pwm_solution.py`입니다. 학생은 먼저
과제 파일의 `brightness_for_distance(distance_m)`를 완성합니다.
10cm 이하는 밝기1, 80cm 이상은0, 그 사이는 선형으로 연결합니다.
각 예제에 `--mock --duration 5`를 붙이면 GPIO 없이 모의 입력을 시험합니다.

## 후반 3시간

카메라와 OpenCV, YOLO, MediaPipe를 실행하고 ROS2 Python publisher/listener를 연결합니다.
MediaPipe 가위바위보를 먼저 한 프로그램으로 실행합니다.

```bash
cd ~/pi_basics_6h
.venv-mp/bin/python vision/rps_led.py
```

이후 세 터미널에서 각각 다음을 실행합니다. 각 터미널의 작업 위치는 같습니다.

```bash
cd ~/pi_basics_6h/ros2_python_labs
bash run_lab.sh io-rps
```

```bash
cd ~/pi_basics_6h/ros2_python_labs
bash run_lab.sh rps-pub
```

```bash
cd ~/pi_basics_6h/ros2_python_labs
bash run_lab.sh rps-sub
```

`io-rps`는 파이 OS에서 카메라·MediaPipe·LED를 사용합니다. publisher와 listener는
기존 ROS2 Humble 컨테이너에서 실행합니다. `run_lab.sh`가 환경 선택을 처리합니다.
직접 실행 예제와 ROS 연동 예제는 동시에 실행하지 않습니다.

## 배선 기준

| 장치 | BCM | 물리 핀 |
|---|---:|---:|
| 버튼 입력 | 27 | 13 |
| 처음 버튼 실습 LED | 17 | 11 |
| PWM LED | 18 | 12 |
| 초음파 TRIG | 23 | 16 |
| 초음파 ECHO (분압 후) | 24 | 18 |
| 가위 빨강 LED | 6 | 31 |
| 바위 파랑 LED | 13 | 33 |
| 보 노랑 LED | 19 | 35 |

LED마다 GPIO와 LED 긴 다리(+) 사이에 330Ω 저항을 하나씩 넣고, 짧은 다리(-)는
GND에 연결합니다. 노랑 LED는 독립된 LED 한 개입니다. RGB LED의 두 색을 섞는 방식이 아닙니다.
버튼은 BCM27과 GND 사이에 연결하며 내부 풀업을 사용합니다. 5V에는 연결하지 않습니다.
4핀 버튼은 같은 쪽 두 다리가 내부에서 연결될 수 있으므로, 누를 때만 서로 연결되는
두 단자를 사용합니다. 전원 분리 상태에서 배선합니다.

HC-SR04 VCC는 5V, GND는 공통 GND입니다. ECHO는 1kΩ 저항을 거쳐 BCM24에,
BCM24 접점에서 2kΩ 저항을 거쳐 GND에 연결합니다. ECHO를 GPIO에 직접 연결하지 않습니다.
PWM은 GPIOZero/lgpio 소프트웨어 PWM 100Hz입니다. 하드웨어 PWM 오버레이는 사용하지 않습니다.

## 손 모양과 코드의 대응

| 모델 결과 | 예제 상태 | LED |
|---|---|---|
| Victory | SCISSORS | 빨강 |
| Closed_Fist | ROCK | 파랑 |
| Open_Palm | PAPER | 노랑 |
| 미확인, 손 없음, 두 손, 낮은 신뢰도 | UNKNOWN | 모두 꺼짐 |

동일 결과가 신뢰도0.6 이상으로 3프레임 이어져야 켜집니다. 다른 모양으로 바뀌는 동안은
확정 전까지 꺼지고, ROS 입력/출력 명령이 오래되면 꺼집니다. 이 예제는 손 모양 분류이며
상대방과 승패를 겨루는 게임은 추가 과제로 만들 수 있습니다.

## 실행 전 점검과 설명

`bash preflight_v2.sh`는 패키지와 모델, 컨테이너를 확인합니다. 실제 배선과 영상 인식은
각 예제를 실행해 확인해야 합니다. 카메라 모델/포트 설정은 이미 배포된 장비의 설정을 유지합니다.
교재의 CAM0 설정 절차와 `rpicam-hello --list-cameras`로 확인할 수 있습니다.
자세한 코드 설명은 `docs/01_버튼_PWM_초음파_실습.txt`와
`가위바위보_실행과_코드설명.txt`를 참고합니다.

기존 OpenCV, YOLO, ROS 초음파 예제도 함께 포함합니다. 이전 과정의 실측 검증 기록은
이번 새 예제의 실제 회로 검증을 대신하지 않습니다. 수업 전 새 예제로 배선과 손 모양을 확인합니다.
