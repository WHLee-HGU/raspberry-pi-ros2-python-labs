#!/usr/bin/env bash
# Read-only host inspection; run before class and save its output.
set -u
root_dir="$(cd "$(dirname "$0")" && pwd)"
echo '[HOST OS]'
cat /etc/os-release
uname -m
free -h
df -h /
echo '[GPIO]'
id
ls -l /dev/gpiochip* 2>/dev/null || true
python3 -c 'import gpiozero, lgpio; print("GPIO imports OK")'
python3 "$root_dir/labs/gpio_backend.py" --inspect
echo '[ROS CONTAINER]'
sudo docker image inspect pi-class:humble --format '{{.Id}} {{.Architecture}}' || true
sudo docker ps -a --format '{{.Names}} {{.Image}} {{.Status}}'
echo '[POWER / TEMPERATURE]'
if command -v vcgencmd >/dev/null; then
  vcgencmd get_throttled
  vcgencmd measure_temp
fi
