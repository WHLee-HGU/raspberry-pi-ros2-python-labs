"""CONTAINER: a teaching controller publishing ONLY /edu/cmd_vel.
No motor driver is included. Stale or invalid range means STOP.
"""
import time
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Range
from std_msgs.msg import Bool
from geometry_msgs.msg import Twist
from policy import decide

class Decision(Node):
    def __init__(self):
        super().__init__('class_decision')
        self.distance = None
        self.received = None
        self.state = 'STOP'
        self.cmd = self.create_publisher(Twist, '/edu/cmd_vel', 10)
        self.stop_pub = self.create_publisher(Bool, '/edu/stop', 10)
        self.create_subscription(Range, '/edu/range', self.on_range, 10)
        self.create_timer(0.05, self.tick)
        self.get_logger().info('Virtual controller started in STOP; no motor connection.')

    def on_range(self, msg):
        self.distance = msg.range
        self.received = time.monotonic()

    def tick(self):
        age = float('inf') if self.received is None else time.monotonic()-self.received
        new = decide(self.state, self.distance, age)
        if new != self.state:
            self.get_logger().info(f'{self.state} -> {new}')
        self.state = new
        msg = Twist()
        msg.linear.x = 0.1 if new == 'GO' else 0.0
        self.cmd.publish(msg)
        stop = Bool()
        stop.data = new == 'STOP'
        self.stop_pub.publish(stop)

def main():
    rclpy.init()
    node = Decision()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if rclpy.ok():
            node.cmd.publish(Twist())
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()
