"""Teacher solution: near 10cm = fully lit, far 80cm = off, linear between.

HOST Python, no ROS/Docker. LED BCM18/physical12 via 330 ohm to GND.
HC-SR04 TRIG BCM23/physical16, divided ECHO BCM24/physical18.
"""
import math
from distance_pwm_common import main


def brightness_for_distance(distance_m):
    if distance_m is None or not math.isfinite(distance_m) or not 0.02 <= distance_m <= 2.0:
        return 0.0
    if distance_m <= 0.10:
        return 1.0
    if distance_m >= 0.80:
        return 0.0
    return (0.80 - distance_m) / (0.80 - 0.10)


if __name__ == '__main__':
    main(brightness_for_distance, __doc__)
