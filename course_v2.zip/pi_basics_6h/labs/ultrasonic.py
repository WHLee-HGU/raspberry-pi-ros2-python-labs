"""Bounded HC-SR04 readings in METRES, or None on invalid/missing echo.

TRIG BCM23/physical16. ECHO BCM24/physical18 THROUGH 1k/2k voltage divider.
Timing in Linux userspace is approximate. This is a stationary classroom demo.
"""
import math
import time


class Ultrasonic:
    def __init__(self, echo=24, trigger=23, timeout_s=0.03, pin_factory=None):
        if not math.isfinite(timeout_s) or timeout_s <= 0:
            raise ValueError('timeout_s must be finite and > 0')
        from gpiozero import DigitalInputDevice, DigitalOutputDevice
        self.trigger = self.echo = None
        self.timeout_s = timeout_s
        try:
            self.trigger = DigitalOutputDevice(trigger, initial_value=False, pin_factory=pin_factory)
            self.echo = DigitalInputDevice(echo, pull_up=False, pin_factory=pin_factory)
        except BaseException:
            self.close()
            raise

    @property
    def distance(self):
        if self.echo.value:
            return None
        self.trigger.on()
        try:
            time.sleep(0.00001)  # 10 microsecond trigger pulse
        finally:
            self.trigger.off()
        deadline = time.perf_counter() + self.timeout_s
        while not self.echo.value:
            if time.perf_counter() >= deadline:
                return None
        started = time.perf_counter()
        deadline = started + self.timeout_s
        while self.echo.value:
            if time.perf_counter() >= deadline:
                return None
        distance_m = (time.perf_counter() - started) * 343.0 / 2.0
        return distance_m if 0.02 <= distance_m <= 2.0 else None

    def close(self):
        # A failed action must not prevent the remaining devices from closing.
        errors = []
        for device in (self.trigger, self.echo):
            if device is not None:
                if device is self.trigger:
                    try:
                        device.off()
                    except Exception as exc:
                        errors.append(exc)
                try:
                    device.close()
                except Exception as exc:
                    errors.append(exc)
        self.trigger = self.echo = None
        if errors:
            raise RuntimeError('Ultrasonic cleanup failed') from errors[0]
