"""Shared measurement/cleanup loop for the assignment and the teacher solution.

Student task: edit brightness_for_distance() in distance_pwm_assignment.py.
No Docker/ROS is used in the first three-hour lesson.
"""
from contextlib import ExitStack
import math
import time
from lab_support import arguments

MOCK_DISTANCES_M = (0.10, 0.45, 0.80, 1.0, None)


def apply_mapping(mapping, distance_m):
    """Keep invalid input off and reject mapping results outside the PWM range."""
    if distance_m is None or not math.isfinite(distance_m) or not 0.02 <= distance_m <= 2.0:
        return 0.0
    brightness = mapping(distance_m)
    if not isinstance(brightness, (int, float)) or not math.isfinite(brightness):
        raise ValueError('brightness_for_distance() must return a finite number')
    if not 0 <= brightness <= 1:
        raise ValueError('brightness_for_distance() must return a value between 0 and 1')
    return brightness


def run(mapping, args):
    with ExitStack() as resources:
        sensor = led = None
        if not args.mock:
            from gpiozero import PWMLED
            from gpio_backend import create_header_factory
            from ultrasonic import Ultrasonic
            factory = create_header_factory()
            resources.callback(factory.close)
            led = resources.enter_context(PWMLED(
                18, initial_value=0, frequency=100, pin_factory=factory))
            sensor = Ultrasonic(echo=24, trigger=23, pin_factory=factory)
            resources.callback(sensor.close)
            time.sleep(0.2)
        print('MOCK: no GPIO' if args.mock else 'HC-SR04 BCM23/24, PWM LED BCM18', flush=True)
        started = time.monotonic()
        try:
            while args.duration == 0 or time.monotonic() - started < args.duration:
                try:
                    distance_m = (MOCK_DISTANCES_M[int(time.monotonic() - started) % len(MOCK_DISTANCES_M)]
                                  if args.mock else sensor.distance)
                except (OSError, RuntimeError) as exc:
                    print(f'Sensor read failed: {exc}', flush=True)
                    distance_m = None
                brightness = apply_mapping(mapping, distance_m)
                if led is not None:
                    led.value = brightness
                distance_text = 'invalid' if distance_m is None else f'{distance_m * 100:.1f}cm'
                print(f'distance={distance_text}, brightness={brightness:.2f}', flush=True)
                time.sleep(0.1)  # Keep at least 60ms between HC-SR04 triggers.
        except KeyboardInterrupt:
            pass
        finally:
            if led is not None:
                led.off()
            print('brightness=0.00, finished', flush=True)


def main(mapping, description):
    run(mapping, arguments(description))
