"""Button BCM27/physical13 to GND. LED BCM17/physical11 via 330 ohm to GND.

Hold the button to light the LED, release to turn it off. Run on the Pi HOST.
--mock demonstrates the logic without a Pi, gpiozero, or physical wiring.
"""
from contextlib import ExitStack
import time
from lab_support import arguments


def run(args):
    with ExitStack() as resources:
        led = button = None
        if not args.mock:
            from gpiozero import LED, Button
            from gpio_backend import create_header_factory
            factory = create_header_factory()
            resources.callback(factory.close)
            led = resources.enter_context(LED(17, initial_value=False, pin_factory=factory))
            button = resources.enter_context(Button(
                27, pull_up=True, bounce_time=0.05, pin_factory=factory))
        print('MOCK: no GPIO' if args.mock else 'Button BCM27, LED BCM17', flush=True)
        start = time.monotonic()
        previous = None
        try:
            while args.duration == 0 or time.monotonic() - start < args.duration:
                # True = pressed. Pull-up wiring produces a low electrical level when pressed.
                pressed = (int((time.monotonic() - start) / 0.5) % 2 == 1
                           if args.mock else button.is_pressed)
                if led is not None:
                    if pressed:
                        led.on()
                    else:
                        led.off()
                if pressed != previous:
                    print(f'pressed={pressed}, LED={"ON" if pressed else "OFF"}', flush=True)
                    previous = pressed
                time.sleep(0.02)
        except KeyboardInterrupt:
            pass
        finally:
            if led is not None:
                led.off()
            print('LED=OFF, finished', flush=True)


def main():
    run(arguments(__doc__))


if __name__ == '__main__':
    main()
