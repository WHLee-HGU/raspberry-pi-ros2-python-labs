"""Pi HOST: CSV + atomic JSON bridge. --source mock works without GPIO.
HC-SR04: TRIG=BCM23, ECHO=BCM24 THROUGH A VOLTAGE DIVIDER.
--led uses BCM17; LED on means STOP. This code does not drive motors.
"""
import argparse
import csv
import json
import math
import os
import time
from pathlib import Path
from policy import decide

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--source', choices=['mock', 'ultrasonic'], default='mock')
    ap.add_argument('--duration', type=float, default=60, help='seconds; 0 = until Ctrl+C')
    ap.add_argument('--led', action='store_true')
    args = ap.parse_args()
    if args.duration < 0:
        ap.error('duration must be >= 0')
    out = Path(__file__).resolve().parents[1] / 'data'
    out.mkdir(exist_ok=True)
    sensor = led = factory = previous_factory = None

    def publish(value):
        # None is intentional: invalid JSON NaN is never written.
        payload = {'distance_m': value, 'timestamp_s': time.time()}
        tmp = out / 'latest.tmp'
        tmp.write_text(json.dumps(payload, allow_nan=False), encoding='utf-8')
        os.replace(tmp, out / 'latest.json')

    state = 'STOP'
    started = time.monotonic()
    sequence = [1.0, 0.6, 0.30, 0.24, 0.27, 0.31, None]
    try:
        if args.source == 'ultrasonic' or args.led:
            from gpiozero import Device
            from gpio_backend import create_header_factory
            factory = create_header_factory()
            previous_factory = Device.pin_factory
            Device.pin_factory = factory
        if args.source == 'ultrasonic':
            from ultrasonic import Ultrasonic
            sensor = Ultrasonic(echo=24, trigger=23)
        if args.led:
            from gpiozero import LED
            led = LED(17, initial_value=True, pin_factory=factory)
        with (out / 'range.csv').open('w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['elapsed_s', 'distance_m', 'state', 'source'])
            while args.duration == 0 or time.monotonic() - started < args.duration:
                elapsed = time.monotonic() - started
                try:
                    value = sensor.distance if sensor is not None else sequence[int(elapsed) % len(sequence)]
                    if value is not None and not math.isfinite(value):
                        value = None
                except (RuntimeError, OSError) as exc:
                    print('Sensor read failed:', exc)
                    value = None
                state = decide(state, value)
                if led is not None:
                    led.value = state == 'STOP'
                publish(value)
                writer.writerow([round(elapsed, 3), value, state, args.source])
                f.flush()
                print(f'{elapsed:6.1f}s distance_m={value} state={state}', flush=True)
                time.sleep(0.1)
    except KeyboardInterrupt:
        pass
    finally:
        try:
            publish(None)
        finally:
            # A failed JSON write or one failed close must not prevent the
            # remaining devices from being released. Report cleanup failures
            # after every action has been attempted and the factory restored.
            actions = []
            if led is not None:
                actions.extend([('LED off', led.off), ('LED close', led.close)])
            if sensor is not None:
                actions.append(('sensor close', sensor.close))
            if factory is not None:
                actions.append(('factory close', factory.close))
            errors = []
            try:
                for label, action in actions:
                    try:
                        action()
                    except Exception as exc:
                        errors.append((label, exc))
            finally:
                if factory is not None:
                    Device.pin_factory = previous_factory
            if errors:
                detail = '; '.join(f'{label}: {exc}' for label, exc in errors)
                raise RuntimeError(f'GPIO cleanup failed: {detail}') from errors[0][1]

if __name__ == '__main__':
    main()
