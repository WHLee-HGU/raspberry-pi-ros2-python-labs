"""CONTAINER: publish simulated or file-bridged range on /edu/range.
Usage: python3 labs/ros_range_pub.py --ros-args -p source:=file
"""
import json
import math
import time
from pathlib import Path
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Range

class RangePublisher(Node):
    def __init__(self):
        super().__init__('class_range_publisher')
        self.declare_parameter('source', 'mock')
        self.source = self.get_parameter('source').value
        if self.source not in ('mock', 'file'):
            raise ValueError('source must be mock or file')
        self.file = Path(__file__).resolve().parents[1] / 'data' / 'latest.json'
        self.pub = self.create_publisher(Range, '/edu/range', 10)
        self.started = time.monotonic()
        self.create_timer(0.1, self.tick)

    def tick(self):
        if self.source == 'mock':
            values = [1.0, 0.6, 0.30, 0.24, 0.27, 0.31, math.nan]
            value = values[int(time.monotonic()-self.started) % len(values)]
        else:
            try:
                sample = json.loads(self.file.read_text(encoding='utf-8'))
                age = time.time() - float(sample['timestamp_s'])
                value = float(sample['distance_m'])
                if not math.isfinite(age) or not 0 <= age <= 0.5:
                    value = math.nan
            except (OSError, KeyError, TypeError, ValueError):
                value = math.nan
        msg = Range()
        # This stamp is publication time; file freshness is checked above.
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'class_ultrasonic'
        msg.radiation_type = Range.ULTRASOUND
        msg.field_of_view = 0.26  # teaching approximation; calibrate a real sensor
        msg.min_range = 0.02
        msg.max_range = 2.0
        msg.range = float(value)
        self.pub.publish(msg)

def main():
    rclpy.init()
    node = RangePublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()
