"""Print HC-SR04 distance in cm, with no CSV, ROS or LED output.

TRIG BCM23/physical16. Divided ECHO BCM24/physical18. HOST Python3.
--mock runs without GPIO. Stop with Ctrl+C.
"""
from contextlib import ExitStack
import time
from lab_support import arguments


def main():
    args = arguments(__doc__)
    with ExitStack() as resources:
        sensor = None
        if not args.mock:
            from gpio_backend import create_header_factory
            from ultrasonic import Ultrasonic
            factory = create_header_factory()
            resources.callback(factory.close)
            sensor = Ultrasonic(echo=24, trigger=23, pin_factory=factory)
            resources.callback(sensor.close)
            time.sleep(0.2)
        print('MOCK: no GPIO' if args.mock else 'HC-SR04 BCM23/24', flush=True)
        sequence = (0.10, 0.45, 0.80, None)
        started = time.monotonic()
        try:
            while args.duration == 0 or time.monotonic() - started < args.duration:
                try:
                    distance_m = (sequence[int(time.monotonic() - started) % len(sequence)]
                                  if args.mock else sensor.distance)
                except (OSError, RuntimeError) as exc:
                    print(f'Sensor read failed: {exc}', flush=True)
                    distance_m = None
                if distance_m is None:
                    print('distance=invalid (no valid echo)', flush=True)
                else:
                    distance_cm = distance_m * 100
                    print(f'distance={distance_cm:.1f}cm', flush=True)
                time.sleep(0.1)
        except KeyboardInterrupt:
            pass
        finally:
            print('finished', flush=True)


if __name__ == '__main__':
    main()
