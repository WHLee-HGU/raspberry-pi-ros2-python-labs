"""Small shared CLI helper. Importing this file never requests GPIO lines."""
import argparse
import math
import signal


def arguments(description):
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument('--mock', action='store_true', help='No GPIO, use simulated input/output')
    parser.add_argument('--duration', type=float, default=0, help='Seconds; 0 means until Ctrl+C')
    args = parser.parse_args()
    if not math.isfinite(args.duration) or args.duration < 0:
        parser.error('--duration must be a finite number >= 0')

    def stop(_signal, _frame):
        raise KeyboardInterrupt

    signal.signal(signal.SIGTERM, stop)
    return args
