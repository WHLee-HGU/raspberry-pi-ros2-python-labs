"""Assignment: distance controls LED brightness. Edit ONLY the function below.

Valid distance is measured in METRES. Near 0.10m -> 1, far 0.80m -> 0.
The helper turns invalid/missing echo off and releases GPIO on exit.
"""
from distance_pwm_common import main


def brightness_for_distance(distance_m):
    # TODO 1: return 1.0 when distance_m <= 0.10
    # TODO 2: return 0.0 when distance_m >= 0.80
    # TODO 3: map 0.10~0.80 m linearly into brightness 1.0~0.0
    return 0.0  # Safe starting value: the unfinished assignment leaves the LED off.


if __name__ == '__main__':
    main(brightness_for_distance, __doc__)
