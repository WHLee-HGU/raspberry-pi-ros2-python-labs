"""Distance decision for an LED / virtual robot, not a certified safety device."""
import math

def decide(previous, distance_m, age_s=0.0, timeout_s=0.5):
    if distance_m is None or not math.isfinite(distance_m):
        return 'STOP'
    if not math.isfinite(age_s) or age_s < 0 or age_s > timeout_s:
        return 'STOP'
    if not 0.02 <= distance_m <= 2.0:
        return 'STOP'
    if distance_m <= 0.25:
        return 'STOP'
    if distance_m >= 0.30:
        return 'GO'
    return previous if previous in ('STOP', 'GO') else 'STOP'
