"""Any Python 3: summarize measured or simulated range.csv; no extra packages."""
import csv
import statistics
from pathlib import Path

p = Path(__file__).resolve().parents[1] / 'data' / 'range.csv'
rows = list(csv.DictReader(p.open(newline='')))
values = [float(r['distance_m']) for r in rows if r['distance_m']]
times = [float(r['elapsed_s']) for r in rows]
gaps = [b-a for a,b in zip(times, times[1:])]
print('samples:', len(rows), 'invalid:', len(rows)-len(values))
print('source:', sorted(set(r['source'] for r in rows)))
if values:
    print('distance mean (m):', round(statistics.mean(values),4))
    print('distance stddev (m):', round(statistics.pstdev(values),4))
if gaps:
    print('mean interval (s):', round(statistics.mean(gaps),4))
    print('max interval (s):', max(gaps))
