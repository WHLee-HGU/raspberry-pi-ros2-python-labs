"""Pi HOST: button between BCM27 and GND. Internal pull-up enabled."""
import csv
import time
from pathlib import Path
from contextlib import closing
from gpiozero import LED, Button
from gpio_backend import create_header_factory

out = Path(__file__).resolve().parents[1] / 'data' / 'button.csv'
out.parent.mkdir(exist_ok=True)
with closing(create_header_factory()) as factory, LED(
        17, initial_value=False, pin_factory=factory) as led, Button(
        27, pull_up=True, bounce_time=0.05, pin_factory=factory) as button:
    with out.open('w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['elapsed_s', 'pressed'])
        start = time.monotonic()
        try:
            while time.monotonic() - start < 20:
                pressed = button.is_pressed
                led.value = pressed
                writer.writerow([round(time.monotonic()-start, 3), int(pressed)])
                time.sleep(0.05)
        except KeyboardInterrupt:
            pass
        finally:
            led.off()
print(out)
