"""Compatibility entry for the old lesson command.

The second course replaces automatic blinking with a button-controlled LED.
Read and edit button_led.py. The old command python3 labs/blink.py still works.
"""
from button_led import main


if __name__ == '__main__':
    main()
