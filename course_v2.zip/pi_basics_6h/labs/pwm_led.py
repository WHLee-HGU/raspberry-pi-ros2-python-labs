"""LED brightness demo: BCM18/physical12 -> 330 ohm -> LED anode; cathode -> GND.

GPIOZero + lgpio uses SOFTWARE PWM at 100 Hz in this lesson.
Run on the Pi HOST; stop with Ctrl+C. --mock does not request GPIO lines.
"""
from contextlib import ExitStack
import time
from lab_support import arguments

LEVELS = (0.0, 0.25, 0.5, 0.75, 1.0)


def run(args):
    with ExitStack() as resources:
        led = None
        if not args.mock:
            from gpiozero import PWMLED
            from gpio_backend import create_header_factory
            factory = create_header_factory()
            resources.callback(factory.close)
            led = resources.enter_context(PWMLED(
                18, initial_value=0, frequency=100, pin_factory=factory))
        print('MOCK: no GPIO' if args.mock else 'PWM LED BCM18, software PWM 100 Hz', flush=True)
        start = time.monotonic()
        previous = None
        try:
            while args.duration == 0 or time.monotonic() - start < args.duration:
                brightness = LEVELS[int(time.monotonic() - start) % len(LEVELS)]
                if led is not None:
                    led.value = brightness  # 0 = off, 1 = continuously on
                if brightness != previous:
                    print(f'brightness={brightness:.2f}, duty={brightness * 100:.0f}%', flush=True)
                    previous = brightness
                time.sleep(0.02)
        except KeyboardInterrupt:
            pass
        finally:
            if led is not None:
                led.off()
            print('brightness=0.00, finished', flush=True)


def main():
    run(arguments(__doc__))


if __name__ == '__main__':
    main()
