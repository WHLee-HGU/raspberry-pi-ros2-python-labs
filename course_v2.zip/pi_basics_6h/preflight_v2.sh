#!/usr/bin/env bash
# GPIO, 카메라 프레임, LED를 점유하지 않는 수업 전 점검.
set -uo pipefail
course_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$course_dir"
status=0
printf '%s\n' '[수업 코드 버전]'
cat COURSE_VERSION.txt
printf '%s\n' '[기본 GPIO / OpenCV / 카메라 Python]'
python3 -c 'import gpiozero, lgpio, cv2, numpy, picamera2, libcamera; print("기본 패키지 OK")' || status=1
printf '%s\n' '[MediaPipe 가상환경]'
if [[ -x .venv-mp/bin/python ]]; then
  .venv-mp/bin/python -c 'import mediapipe, cv2, numpy, picamera2; print("MediaPipe imports OK")' || status=1
else
  printf '%s\n' 'MISSING .venv-mp: 기존 수업 SD의 가상환경이 필요합니다.'; status=1
fi
printf '%s\n' '[YOLO 가상환경]'
if [[ -x .venv-yolo/bin/python ]]; then
  .venv-yolo/bin/python -c 'import ultralytics, ncnn, cv2; print("YOLO imports OK")' || status=1
else
  printf '%s\n' 'MISSING .venv-yolo'; status=1
fi
printf '%s\n' '[모델]'
printf '97952348cf6a6a4915c2ea1496b4b37ebabc50cbbf80571435643c455f2b0482  models/gesture_recognizer.task\n' | sha256sum --check || status=1
[[ -f models/hand_landmarker.task ]] || { printf '%s\n' 'MISSING models/hand_landmarker.task'; status=1; }
[[ -f models/yolo11n_ncnn_model/model.ncnn.bin ]] || { printf '%s\n' 'MISSING YOLO NCNN 모델'; status=1; }
printf '%s\n' '[ROS2 컨테이너]'
python3 ros2_python_labs/code/check_installation.py || status=1
printf '%s\n' '카메라는 별도로 rpicam-hello --list-cameras 후 rpicam-hello -t 5000으로 확인합니다.'
printf '%s\n' '배선한 LED/버튼/초음파와 실제 손 모양 인식은 각 예제로 직접 확인합니다.'
exit "$status"
