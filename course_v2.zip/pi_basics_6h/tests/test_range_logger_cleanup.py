"""Exercise hardware cleanup through fake devices; never access real GPIO."""
import importlib.util
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'labs'))
SPEC = importlib.util.spec_from_file_location('range_logger_cleanup_subject', ROOT / 'labs/range_logger.py')
logger = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(logger)


class CleanupTests(unittest.TestCase):
    def exercise_write_failure(self, failing_cleanup=()):
        calls = []
        original_factory = object()
        device_class = type('Device', (), {'pin_factory': original_factory})

        def action(name):
            calls.append(name)
            if name in failing_cleanup:
                raise OSError(f'injected {name} failure')

        class Factory:
            def close(self):
                action('factory close')

        factory = Factory()

        class LED:
            def __init__(self, *args, **kwargs):
                self.value = True
                self.asserted_factory = kwargs['pin_factory']
                if self.asserted_factory is not factory:
                    raise AssertionError('LED did not receive the selected factory')

            def off(self):
                action('LED off')

            def close(self):
                action('LED close')

        class Ultrasonic:
            distance = 0.5

            def __init__(self, *args, **kwargs):
                if device_class.pin_factory is not factory:
                    raise AssertionError('sensor did not see the selected factory')

            def close(self):
                action('sensor close')

        gpiozero = types.ModuleType('gpiozero')
        gpiozero.Device, gpiozero.LED = device_class, LED
        backend = types.ModuleType('gpio_backend')
        backend.create_header_factory = lambda: factory
        sensor_module = types.ModuleType('ultrasonic')
        sensor_module.Ultrasonic = Ultrasonic

        def failed_write(path, *args, **kwargs):
            calls.append('JSON write')
            raise OSError('injected JSON write failure')

        with tempfile.TemporaryDirectory(prefix='pi-cleanup-test-') as temporary:
            fake_script = str(Path(temporary) / 'labs/range_logger.py')
            with patch.dict(sys.modules, {
                'gpiozero': gpiozero, 'gpio_backend': backend, 'ultrasonic': sensor_module,
            }), patch.object(logger, '__file__', fake_script), patch.object(
                sys, 'argv', ['range_logger.py', '--source', 'ultrasonic', '--led', '--duration', '1']
            ), patch.object(Path, 'write_text', failed_write):
                expected = RuntimeError if failing_cleanup else OSError
                with self.assertRaises(expected) as raised:
                    logger.main()
        self.assertIs(device_class.pin_factory, original_factory)
        self.assertEqual(calls, [
            'JSON write', 'JSON write', 'LED off', 'LED close', 'sensor close', 'factory close',
        ])
        return raised.exception

    def test_failed_publish_still_closes_every_resource_and_restores_factory(self):
        failure = self.exercise_write_failure()
        self.assertIn('JSON write failure', str(failure))

    def test_failed_device_actions_do_not_skip_other_cleanup(self):
        failure = self.exercise_write_failure(('LED off', 'LED close', 'sensor close', 'factory close'))
        self.assertIn('GPIO cleanup failed', str(failure))
        for label in ('LED off', 'LED close', 'sensor close', 'factory close'):
            self.assertIn(label, str(failure))


if __name__ == '__main__':
    unittest.main()
