import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'labs'))
from policy import decide

class DecisionTests(unittest.TestCase):
    def test_hysteresis_sequence(self):
        state = 'STOP'
        states = []
        for value in [1.0, 0.24, 0.27, 0.30, 0.27]:
            state = decide(state, value)
            states.append(state)
        self.assertEqual(states, ['GO','STOP','STOP','GO','GO'])

    def test_unknown_and_out_of_range_stop(self):
        for value in [None, float('nan'), float('inf'), -1, 0, 2.1]:
            self.assertEqual(decide('GO', value), 'STOP')

    def test_dead_sensor_stops_even_when_last_distance_was_clear(self):
        self.assertEqual(decide('GO', 1.0, age_s=0.501), 'STOP')
        self.assertEqual(decide('GO', 1.0, age_s=0.49), 'GO')

    def test_stop_threshold_and_startup(self):
        self.assertEqual(decide('GO', 0.25), 'STOP')
        self.assertEqual(decide('STOP', 0.27), 'STOP')

if __name__ == '__main__':
    unittest.main()
