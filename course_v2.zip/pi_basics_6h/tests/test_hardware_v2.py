"""Logic, timeout and cleanup tests with fake devices. No GPIO access/import required."""
import importlib
import io
import math
from pathlib import Path
import subprocess
import sys
import types
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'labs'))
from distance_pwm_common import apply_mapping, run
from distance_pwm_solution import brightness_for_distance
from ultrasonic import Ultrasonic


class BrightnessTests(unittest.TestCase):
    def test_near_far_and_midpoint_match_previous_ros_lesson(self):
        for distance, expected in [(0.02, 1), (0.1, 1), (0.45, 0.5), (0.8, 0), (2, 0)]:
            self.assertAlmostEqual(brightness_for_distance(distance), expected)

    def test_invalid_inputs_never_reuse_previous_brightness(self):
        for distance in [None, float('nan'), float('inf'), -1, 0, 0.019, 2.001]:
            self.assertEqual(brightness_for_distance(distance), 0)
            self.assertEqual(apply_mapping(lambda value: self.fail('must not call mapping'), distance), 0)

    def test_mapping_is_monotone_and_bounded(self):
        values = [brightness_for_distance(i / 100) for i in range(2, 201)]
        self.assertTrue(all(0 <= value <= 1 for value in values))
        self.assertTrue(all(a >= b for a, b in zip(values, values[1:])))

    def test_student_mapping_error_is_explicit(self):
        for output in [None, '0.5', float('nan'), float('inf'), -0.1, 1.01]:
            with self.subTest(output=output), self.assertRaises(ValueError):
                apply_mapping(lambda _distance: output, 0.45)


class FakeClock:
    def __init__(self):
        self.elapsed = 0

    def perf_counter(self):
        self.elapsed += 0.001
        return self.elapsed


class Echo:
    def __init__(self, values):
        self.values = iter(values)
        self.last = 0

    @property
    def value(self):
        self.last = next(self.values, self.last)
        return self.last


class Trigger:
    def __init__(self):
        self.states = []

    def on(self):
        self.states.append(1)

    def off(self):
        self.states.append(0)


class SensorTimeoutTests(unittest.TestCase):
    def sensor(self, echo):
        sensor = object.__new__(Ultrasonic)
        sensor.echo, sensor.trigger, sensor.timeout_s = echo, Trigger(), 0.03
        return sensor

    def test_missing_echo_and_stuck_high_are_bounded_and_return_none(self):
        for echo in [Echo([0]), Echo([0, 1])]:
            sensor, clock = self.sensor(echo), FakeClock()
            with patch('ultrasonic.time.perf_counter', clock.perf_counter), patch('ultrasonic.time.sleep'):
                self.assertIsNone(sensor.distance)
            self.assertLess(clock.elapsed, 0.07)
            self.assertEqual(sensor.trigger.states[-1], 0)

    def test_high_before_trigger_is_invalid_without_emitting_pulse(self):
        sensor = self.sensor(Echo([1]))
        self.assertIsNone(sensor.distance)
        self.assertEqual(sensor.trigger.states, [])

    def test_valid_echo_uses_round_trip_time_and_metres(self):
        sensor, clock = self.sensor(Echo([0, 0, 1, 1, 0])), FakeClock()
        with patch('ultrasonic.time.perf_counter', clock.perf_counter), patch('ultrasonic.time.sleep'):
            self.assertAlmostEqual(sensor.distance, 0.343)
        self.assertEqual(sensor.trigger.states, [1, 0])


class CleanupTests(unittest.TestCase):
    def test_bad_student_formula_switches_off_and_closes_resources(self):
        calls = []

        class Factory:
            def close(self):
                calls.append('factory.close')

        class LED:
            def __init__(self, pin, **kwargs):
                self.value = 0
                self.assert_pin = pin
                if pin != 18 or kwargs['frequency'] != 100:
                    raise AssertionError('changed PWM wiring/frequency')

            def __enter__(self):
                return self

            def __exit__(self, *_args):
                calls.append('led.close')

            def off(self):
                calls.append('led.off')

        class Sensor:
            distance = 0.45

            def __init__(self, **kwargs):
                if (kwargs['trigger'], kwargs['echo']) != (23, 24):
                    raise AssertionError('changed ultrasonic wiring')

            def close(self):
                calls.append('sensor.close')

        fake_gpio = types.ModuleType('gpiozero')
        fake_gpio.PWMLED = LED
        fake_backend = types.ModuleType('gpio_backend')
        fake_backend.create_header_factory = Factory
        fake_sensor = types.ModuleType('ultrasonic')
        fake_sensor.Ultrasonic = Sensor
        args = types.SimpleNamespace(mock=False, duration=0.1)
        with patch.dict(sys.modules, {
            'gpiozero': fake_gpio, 'gpio_backend': fake_backend, 'ultrasonic': fake_sensor,
        }), patch('distance_pwm_common.time.sleep'), patch('sys.stdout', io.StringIO()):
            with self.assertRaises(ValueError):
                run(lambda _distance: 1.5, args)
        self.assertEqual(calls, ['led.off', 'sensor.close', 'led.close', 'factory.close'])

    def test_all_entries_have_hardware_free_mock_mode(self):
        for entry in ['button_led.py', 'blink.py', 'pwm_led.py', 'distance_read.py',
                      'distance_pwm_assignment.py', 'distance_pwm_solution.py']:
            with self.subTest(entry=entry):
                result = subprocess.run(
                    [sys.executable, str(ROOT / 'labs' / entry), '--mock', '--duration', '0.12'],
                    capture_output=True, text=True, timeout=5)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertIn('MOCK: no GPIO', result.stdout)
                self.assertIn('finished', result.stdout)


if __name__ == '__main__':
    unittest.main()
