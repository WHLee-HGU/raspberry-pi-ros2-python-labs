"""카메라/GPIO 없이 가위바위보, 중단 시 꺼짐, 잘못된 LED 명령을 시험합니다."""
from pathlib import Path
import sys
import types
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'ros2_python_labs/code'))
from rps_policy import GESTURES, StableRps, classify_rps, fresh_rps, rps_colors
from vision_policy import encode_state, decode_state
from led_output import command_values


def category(name, score=0.9):
    return [[types.SimpleNamespace(category_name=name, score=score)]]


class RpsPolicyTests(unittest.TestCase):
    def test_official_model_mapping(self):
        for name, expected in [('Victory', 'SCISSORS'), ('Closed_Fist', 'ROCK'), ('Open_Palm', 'PAPER')]:
            with self.subTest(name=name):
                self.assertEqual(classify_rps(category(name)), expected)

    def test_ambiguous_results_are_unknown(self):
        for categories, count in [(category('Victory'), 0), (category('Victory')*2, 2),
                                  ([], 1), ([[]], 1), (category('Thumb_Up'), 1),
                                  (category('Victory', 0.59), 1),
                                  (category('Victory', float('nan')), 1),
                                  (category('Victory', 1.1), 1)]:
            self.assertEqual(classify_rps(categories, count), 'UNKNOWN')

    def test_three_frames_before_each_color_change(self):
        stable = StableRps(3)
        self.assertEqual([stable.update('ROCK') for _ in range(3)], ['UNKNOWN', 'UNKNOWN', 'ROCK'])
        self.assertEqual(stable.update('SCISSORS'), 'UNKNOWN')
        self.assertEqual(stable.update('SCISSORS'), 'UNKNOWN')
        self.assertEqual(stable.update('SCISSORS'), 'SCISSORS')
        self.assertEqual(stable.update('UNKNOWN'), 'UNKNOWN')
        self.assertEqual(stable.update('SCISSORS'), 'UNKNOWN')

    def test_valid_gestures_are_one_hot(self):
        for gesture, expected in [('SCISSORS', 'red'), ('ROCK', 'blue'), ('PAPER', 'yellow')]:
            colors = rps_colors(gesture)
            self.assertEqual(sum(colors.values()), 1)
            self.assertEqual(colors[expected], 1)
        self.assertEqual(sum(rps_colors('UNKNOWN').values()), 0)
        self.assertEqual(sum(rps_colors('other').values()), 0)

    def test_stale_or_impossible_timestamp_switches_off(self):
        self.assertEqual(fresh_rps('ROCK', 100, 101), 'ROCK')
        for stamp in (99.99, 101.21, float('nan'), float('inf'), True, '100', None):
            self.assertEqual(fresh_rps('ROCK', stamp, 101), 'UNKNOWN')

    def test_publisher_does_not_refresh_old_camera_result(self):
        sample = {'payload': {'gesture': 'PAPER'}, 'timestamp_s': 100.0}
        message = encode_state(sample, 'gesture', GESTURES, 100.8)
        label, captured = decode_state(message, 'gesture', GESTURES, 100.9)
        self.assertEqual((label, captured), ('PAPER', 100.0))
        self.assertEqual(fresh_rps(label, captured, 101.01), 'UNKNOWN')
        stale_message = encode_state(sample, 'gesture', GESTURES, 101.01)
        self.assertEqual(decode_state(stale_message, 'gesture', GESTURES, 101.01)[0], 'UNKNOWN')

    def test_output_rejects_multiple_colors_fraction_missing_and_nan(self):
        for payload in ({'red': 1.0, 'blue': 1.0, 'yellow': 0.0},
                        {'red': 0.5, 'blue': 0.0, 'yellow': 0.0},
                        {'red': 1.0, 'blue': 0.0},
                        {'red': float('nan'), 'blue': 0.0, 'yellow': 0.0}):
            values, reason = command_values('rps_led', {'payload': payload})
            self.assertEqual(sum(values.values()), 0.0)
            self.assertNotEqual(reason, 'fresh')
        for gesture in GESTURES:
            values, reason = command_values('rps_led', {'payload': rps_colors(gesture)})
            self.assertEqual(reason, 'fresh')
            self.assertEqual(sum(values.values()), 0 if gesture == 'UNKNOWN' else 1)

    def test_missing_command_switches_all_off(self):
        values, reason = command_values('rps_led', None)
        self.assertEqual(sum(values.values()), 0)
        self.assertEqual(reason, 'stale_or_missing')


if __name__ == '__main__':
    unittest.main()
