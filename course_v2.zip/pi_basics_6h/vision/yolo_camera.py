"""Pi Desktop: local YOLO nano NCNN model. No auto-download during class."""
import argparse
import subprocess
import time
from pathlib import Path
import cv2
from camera_source import FrameSource
from ultralytics import YOLO

ap = argparse.ArgumentParser()
ap.add_argument('--source', default='picamera2')
ap.add_argument('--model', default='models/yolo11n_ncnn_model')
ap.add_argument('--imgsz', type=int, default=320)
ap.add_argument('--conf', type=float, default=0.4)
ap.add_argument('--capture-on-detection', type=Path,
                help='Teacher option: save one Wayland Desktop PNG after 5 detection-positive frames (requires grim)')
ap.add_argument('--capture-class', help='Only arm the screenshot for this model class name, such as cup')
args = ap.parse_args()
if not Path(args.model).exists():
    raise SystemExit('Missing local YOLO model; teacher exports it before class.')
model = YOLO(args.model, task='detect')
cap = FrameSource(args.source)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
if not cap.isOpened():
    raise SystemExit('Cannot open camera/video.')
detected_frames = 0
capture_done = False
cv2.namedWindow('YOLO nano - Q to quit', cv2.WINDOW_NORMAL)
cv2.resizeWindow('YOLO nano - Q to quit', 800, 600)
cv2.moveWindow('YOLO nano - Q to quit', 480, 120)
try:
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        start = time.perf_counter()
        result = model.predict(frame, imgsz=args.imgsz, conf=args.conf,
                               device='cpu', verbose=False)[0]
        ms = (time.perf_counter()-start)*1000
        display = result.plot()
        cv2.putText(display, f'inference pipeline: {ms:.1f} ms', (10,30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,255,0), 2)
        cv2.imshow('YOLO nano - Q to quit', display)
        if cv2.waitKey(1) & 0xff == ord('q'):
            break
        labels = [result.names[int(cls)] for cls in result.boxes.cls.tolist()]
        matched = bool(labels) and (not args.capture_class or args.capture_class in labels)
        detected_frames = detected_frames + 1 if matched else 0
        if args.capture_on_detection and not capture_done and detected_frames >= 5:
            args.capture_on_detection.parent.mkdir(parents=True, exist_ok=True)
            try:
                subprocess.run(['grim', '-t', 'png', str(args.capture_on_detection)],
                               check=True, timeout=10)
                print('DETECTION_CAPTURE_SAVED: ' + str(args.capture_on_detection), flush=True)
            except (OSError, subprocess.SubprocessError) as exc:
                print('Detection screenshot failed: ' + str(exc), flush=True)
            capture_done = True
finally:
    cap.release()
    cv2.destroyAllWindows()
