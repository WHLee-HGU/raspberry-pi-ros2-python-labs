"""Teacher: run BEFORE class, on a networked Pi. Models stay in models/."""
import argparse
import os
import urllib.request
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument('kind', choices=['mediapipe', 'yolo'])
args = ap.parse_args()
root = Path(__file__).resolve().parents[1]
models = root / 'models'
models.mkdir(exist_ok=True)
if args.kind == 'mediapipe':
    url = ('https://storage.googleapis.com/mediapipe-models/hand_landmarker/'
           'hand_landmarker/float16/1/hand_landmarker.task')
    dest = models / 'hand_landmarker.task'
    if not dest.exists():
        tmp = dest.with_suffix('.download')
        urllib.request.urlretrieve(url, tmp)
        tmp.replace(dest)
    print(dest)
else:
    from ultralytics import YOLO
    os.chdir(models)
    model = YOLO('yolo11n.pt')
    print(model.export(format='ncnn', imgsz=320))
