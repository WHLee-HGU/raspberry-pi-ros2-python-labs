"""교사용 도우미: 추론이 멈춰도 1초가 지나면 세 LED를 끄는 출력 감시기."""
from contextlib import ExitStack
import fcntl
from threading import Event, Lock, Thread
import time
from rps_policy import fresh_rps, rps_colors


class RpsLeds:
    def __init__(self, red=6, blue=13, yellow=19, mock=False):
        self.pins = {'red': red, 'blue': blue, 'yellow': yellow}
        if len(set(self.pins.values())) != 3 or any(not 0 <= pin <= 27 for pin in self.pins.values()):
            raise ValueError('LED 세 개의 BCM 핀은 서로 다른 0~27 값이어야 합니다.')
        self.mock = mock
        self.state, self.captured = 'UNKNOWN', 0.0
        self.lock, self.stop = Lock(), Event()
        self.error = None
        self.worker = None

    def __enter__(self):
        self.resources = ExitStack()
        try:
            lock = self.resources.enter_context(open('/tmp/pi-classroom-led-output.lock', 'a'))
            try:
                fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise RuntimeError('다른 LED 예제를 먼저 Ctrl+C로 종료하세요.') from None
            self.devices = {}
            if not self.mock:
                from gpiozero import LED
                from gpio_backend import create_header_factory
                factory = create_header_factory()
                self.resources.callback(factory.close)
                for color, pin in self.pins.items():
                    self.devices[color] = self.resources.enter_context(
                        LED(pin, initial_value=False, pin_factory=factory))
            self.worker = Thread(target=self._watch, daemon=True)
            self.worker.start()
            return self
        except BaseException:
            self.resources.close()
            raise

    def update(self, gesture, captured):
        if self.error is not None:
            raise RuntimeError('LED 출력 감시기가 중단되었습니다.') from self.error
        with self.lock:
            self.state, self.captured = gesture, captured

    def _watch(self):
        previous = None
        try:
            while not self.stop.is_set():
                with self.lock:
                    gesture = fresh_rps(self.state, self.captured, time.time())
                colors = rps_colors(gesture)
                # 먼저 모두 끈 다음 새 색을 켜서 색 전환 때 두 LED가 함께 켜지지 않게 합니다.
                for device in self.devices.values():
                    device.off()
                for color, value in colors.items():
                    if value and color in self.devices:
                        self.devices[color].on()
                if gesture != previous:
                    print(('MOCK ' if self.mock else '') + f'{gesture}: {colors}', flush=True)
                    previous = gesture
                self.stop.wait(0.05)
        except BaseException as error:
            self.error = error
        finally:
            for device in self.devices.values():
                device.off()

    def __exit__(self, *exc):
        self.stop.set()
        if self.worker is not None:
            self.worker.join(timeout=2)
        self.resources.close()
        if exc[0] is None and self.error is not None:
            raise RuntimeError('LED 출력 감시기가 중단되었습니다.') from self.error
