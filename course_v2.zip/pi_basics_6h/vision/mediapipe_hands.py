"""Pi Desktop: run with .venv-mp/bin/python; uses MediaPipe Tasks API."""
import argparse
import subprocess
import time
from pathlib import Path
import cv2
from camera_source import FrameSource
import mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision

ap = argparse.ArgumentParser()
ap.add_argument('--source', default='picamera2')
ap.add_argument('--model', default='models/hand_landmarker.task')
ap.add_argument('--capture-on-hand', type=Path,
                help='Teacher option: save one Wayland Desktop PNG after 5 hand-positive frames (requires grim)')
args = ap.parse_args()
if not Path(args.model).is_file():
    raise SystemExit('Missing .task model; teacher runs prepare_models.py before class.')
options = vision.HandLandmarkerOptions(
    base_options=python.BaseOptions(model_asset_path=args.model),
    running_mode=vision.RunningMode.VIDEO, num_hands=1)
cap = FrameSource(args.source)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
if not cap.isOpened():
    raise SystemExit('Cannot open camera/video.')
last_ms = -1
hand_frames = 0
capture_done = False
cv2.namedWindow('MediaPipe Tasks - Q to quit', cv2.WINDOW_NORMAL)
cv2.resizeWindow('MediaPipe Tasks - Q to quit', 800, 600)
cv2.moveWindow('MediaPipe Tasks - Q to quit', 480, 120)
try:
    with vision.HandLandmarker.create_from_options(options) as detector:
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            timestamp_ms = max(last_ms+1, time.monotonic_ns()//1_000_000)
            last_ms = timestamp_ms
            start = time.perf_counter()
            result = detector.detect_for_video(
                mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb), timestamp_ms)
            ms = (time.perf_counter()-start)*1000
            for hand in result.hand_landmarks:
                for point in hand:
                    cv2.circle(frame, (int(point.x*frame.shape[1]),
                                       int(point.y*frame.shape[0])), 4, (0,255,0), -1)
            cv2.putText(frame, f'hands={len(result.hand_landmarks)} inference={ms:.1f} ms',
                        (10,30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,255,0), 2)
            cv2.imshow('MediaPipe Tasks - Q to quit', frame)
            if cv2.waitKey(1) & 0xff == ord('q'):
                break
            hand_frames = hand_frames + 1 if result.hand_landmarks else 0
            if args.capture_on_hand and not capture_done and hand_frames >= 5:
                args.capture_on_hand.parent.mkdir(parents=True, exist_ok=True)
                try:
                    subprocess.run(['grim', '-t', 'png', str(args.capture_on_hand)],
                                   check=True, timeout=10)
                    print('HAND_CAPTURE_SAVED: ' + str(args.capture_on_hand), flush=True)
                except (OSError, subprocess.SubprocessError) as exc:
                    print('Hand screenshot failed: ' + str(exc), flush=True)
                capture_done = True
finally:
    cap.release()
    cv2.destroyAllWindows()
