"""BGR frames from Picamera2 (default), USB webcam or local recorded video."""
import time

class FrameSource:
    def __init__(self, source='picamera2'):
        self.picam = self.cap = None
        if source == 'picamera2':
            from picamera2 import Picamera2
            from libcamera import controls
            self.picam = Picamera2()
            # Picamera2 RGB888 arrays are B,G,R in memory, suited to OpenCV.
            config = self.picam.create_video_configuration(
                main={'size': (640,480), 'format': 'RGB888'}, buffer_count=4)
            self.picam.configure(config)
            if 'AfMode' in self.picam.camera_controls:
                self.picam.set_controls({'AfMode': controls.AfModeEnum.Continuous})
            self.picam.start()
            time.sleep(1)
        else:
            import cv2
            value = int(source) if str(source).isdecimal() else source
            self.cap = cv2.VideoCapture(value)

    def set(self, prop, value):
        if self.cap is not None:
            return self.cap.set(prop, value)
        return True

    def isOpened(self):
        return self.picam is not None or self.cap.isOpened()

    def read(self):
        if self.picam is not None:
            return True, self.picam.capture_array('main')
        return self.cap.read()

    def release(self):
        if self.picam is not None:
            self.picam.stop()
            self.picam.close()
        elif self.cap is not None:
            self.cap.release()
