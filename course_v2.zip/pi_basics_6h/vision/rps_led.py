"""MediaPipe 가위바위보와 LED 세 개를 한 프로그램으로 실행합니다. ROS 불필요.

cd ~/pi_basics_6h
.venv-mp/bin/python vision/rps_led.py
가위=빨강 BCM6, 바위=파랑 BCM13, 보=노랑 BCM19. 각 LED에는 330Ω 저항.
"""
import argparse
from pathlib import Path
import sys

# ROS 실습과 동일한 판정/카메라 도우미를 재사용합니다. 이 파일은 rclpy를 사용하지 않습니다.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'ros2_python_labs/code'))
from common import handle_termination
from vision_rps import add_camera_arguments, validate_camera_arguments, recognized_frames
from rps_output import RpsLeds


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    add_camera_arguments(parser)
    parser.add_argument('--red', type=int, default=6)
    parser.add_argument('--blue', type=int, default=13)
    parser.add_argument('--yellow', type=int, default=19)
    args = parser.parse_args()
    validate_camera_arguments(parser, args)
    handle_termination()
    stream = recognized_frames(args)
    try:
        # with가 끝나면 카메라/GPIO를 닫습니다. 감시기는 입력 중단 시 1초 뒤 LED를 끕니다.
        with RpsLeds(args.red, args.blue, args.yellow, mock=args.mock) as leds:
            for gesture, captured in stream:
                leds.update(gesture, captured)
    except KeyboardInterrupt:
        pass
    finally:
        stream.close()


if __name__ == '__main__':
    main()
