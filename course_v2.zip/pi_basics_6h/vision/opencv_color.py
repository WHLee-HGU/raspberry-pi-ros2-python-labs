"""Pi Desktop, system Python. USB camera or recorded video; Q to quit."""
import argparse
import time
import cv2
from camera_source import FrameSource
import numpy as np

ap = argparse.ArgumentParser()
ap.add_argument('--source', default='picamera2', help='picamera2, USB index or local video path')
args = ap.parse_args()
source = int(args.source) if args.source.isdecimal() else args.source
cap = FrameSource(args.source)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
if not cap.isOpened():
    raise SystemExit('Camera/video open failed; check source and other camera apps.')
# Keep both views visible on the classroom HDMI monitor.
for name, x in [('OpenCV - Q to quit', 40), ('HSV mask', 720)]:
    cv2.namedWindow(name, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(name, 640, 480)
    cv2.moveWindow(name, x, 120)
try:
    while True:
        start = time.perf_counter()
        ok, frame = cap.read()
        if not ok:
            break
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        # Green object. Students change the hue range and compare lighting.
        mask = cv2.inRange(hsv, np.array([35, 70, 50]), np.array([85, 255, 255]))
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if contours:
            contour = max(contours, key=cv2.contourArea)
            if cv2.contourArea(contour) > 300:
                x, y, w, h = cv2.boundingRect(contour)
                cv2.rectangle(frame, (x,y), (x+w,y+h), (0,255,0), 2)
                error = (x+w/2-frame.shape[1]/2) / (frame.shape[1]/2)
                cv2.putText(frame, f'center error: {error:+.2f}', (10,30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,0), 2)
        elapsed = time.perf_counter()-start
        cv2.putText(frame, f'capture+process: {elapsed*1000:.1f} ms', (10,60),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255), 2)
        cv2.imshow('OpenCV - Q to quit', frame)
        cv2.imshow('HSV mask', mask)
        if cv2.waitKey(1) & 0xff == ord('q'):
            break
finally:
    cap.release()
    cv2.destroyAllWindows()
