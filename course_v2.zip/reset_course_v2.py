"""기존 수업 SD의 예제만 백업·초기화한다. 패키지와 가상환경은 재설치하지 않는다."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import uuid

VERSION = '2026-11-13-v2'
KEEP = {'.venv', '.venv-base', '.venv-mp', '.venv-yolo', 'models'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_source(source):
    manifest = json.loads((source/'package-manifest.json').read_text(encoding='utf-8'))
    expected = {}
    for entry in manifest['files']:
        rel = Path(entry['path'])
        if rel.is_absolute() or '..' in rel.parts or '\\' in entry['path']:
            raise ValueError('잘못된 배포 경로')
        path = source/rel
        if path.is_symlink() or not path.is_file() or sha(path) != entry['sha256']:
            raise ValueError('배포 파일 검증 실패: '+entry['path'])
        expected[entry['path']] = entry
    actual = {p.relative_to(source).as_posix() for p in source.rglob('*') if p.is_file()}
    if actual != set(expected)|{'package-manifest.json'}:
        raise ValueError('배포 파일 목록 불일치')
    for required in ['reset_course_v2.py','pi_basics_6h/classroom.sh',
                     'pi_basics_6h/labs/button_led.py','pi_basics_6h/labs/pwm_led.py',
                     'pi_basics_6h/labs/distance_pwm_assignment.py',
                     'pi_basics_6h/vision/rps_led.py','pi_basics_6h/ros2_python_labs/run_lab.sh',
                     'pi_basics_6h/models/gesture_recognizer.task']:
        if required not in expected:
            raise ValueError('필수 배포 파일 누락: '+required)
    return manifest


def validate_target(project):
    # 허용하는 대상은 이름이 정해진 수업 폴더 하나뿐이다.
    if project.name != 'pi_basics_6h' or project.parent == Path(project.anchor):
        raise ValueError('대상 폴더 이름은 pi_basics_6h이어야 합니다.')
    for parent in [project, *project.parents]:
        if parent.is_symlink():
            raise ValueError('심볼릭 링크 대상에는 설치하지 않습니다: '+str(parent))
    if not project.is_dir() or not (project/'classroom.sh').is_file():
        raise ValueError('기존 수업 SD의 ~/pi_basics_6h/classroom.sh가 필요합니다.')
    for name in KEEP:
        path = project/name
        if path.is_symlink() or (path.exists() and not path.is_dir()):
            raise ValueError('보존할 환경 폴더가 일반 디렉터리가 아닙니다: '+name)
    backup_root = project.parent/'pi_basics_6h_backups'
    if backup_root.is_symlink():
        raise ValueError('백업 경로가 심볼릭 링크입니다.')


def active_host_labs(project):
    """실행 중인 실습 Python이 있으면 먼저 Ctrl+C하도록 안내한다."""
    proc = Path('/proc')
    if sys.platform != 'linux' or not proc.exists():
        return []
    found = []
    for entry in proc.iterdir():
        if not entry.name.isdecimal() or int(entry.name) == os.getpid():
            continue
        try:
            argv = (entry/'cmdline').read_bytes().decode(errors='replace').split('\0')
            if not argv or 'python' not in Path(argv[0]).name:
                continue
            cwd = (entry/'cwd').resolve()
            for arg in argv[1:]:
                if not arg.endswith('.py'):
                    continue
                script = Path(arg)
                script = script if script.is_absolute() else cwd/script
                if script.resolve().is_relative_to(project):
                    found.append(entry.name)
                    break
        except (OSError, PermissionError):
            pass
    return found


def inspect_docker(project):
    if not shutil.which('docker'):
        return None
    # 실제 수업 환경에서만 실행한다. 타 사용자의 컨테이너는 변경하지 않는다.
    cmd = ['sudo','-n','docker'] if os.geteuid() != 0 else ['docker']
    info = subprocess.run(cmd+['inspect','pi-class'], capture_output=True, text=True, timeout=15)
    if info.returncode:
        daemon = subprocess.run(cmd+['info','--format','{{.ServerVersion}}'],
                                capture_output=True, text=True, timeout=15)
        if daemon.returncode:
            raise ValueError('Docker 확인에 실패했습니다. sudo -v 후 다시 실행하세요.')
        return None
    obj = json.loads(info.stdout)[0]
    mount = [x for x in obj.get('Mounts',[]) if x.get('Destination') == '/work']
    if len(mount) != 1 or Path(mount[0]['Source']).resolve() != project:
        raise ValueError('pi-class 컨테이너의 /work 공유 폴더가 수업 경로와 다릅니다.')
    return {'command':cmd, 'running':obj['State']['Running'],
            'env': [x for x in obj['Config']['Env'] if x.startswith(('ROS_DOMAIN_ID=','ROS_LOCALHOST_ONLY='))]}


def install(source, project, check=False, manage_docker=True):
    manifest = validate_source(source)
    validate_target(project)
    active = active_host_labs(project)
    if active:
        raise ValueError('실행 중인 실습을 모든 터미널에서 Ctrl+C로 종료하세요. PID: '+', '.join(active))
    docker = inspect_docker(project) if manage_docker and sys.platform == 'linux' else None
    print('초기화 대상:', project)
    print('보존:', ', '.join(sorted(KEEP)), '(모델은 동봉 Gesture Recognizer만 검증·갱신)')
    print('기존 코드·데이터·학생 수정본은 형제 백업 폴더로 이동합니다.')
    if check:
        print('CHECK OK: 파일과 대상만 확인했으며 초기화하지 않았습니다.')
        return None
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:8]
    backup_root = project.parent/'pi_basics_6h_backups'
    lock = project.parent/'.pi_course_v2_update.lock'
    fd = os.open(lock, os.O_CREAT|os.O_EXCL|os.O_WRONLY, 0o600)
    os.write(fd, str(os.getpid()).encode())
    os.close(fd)
    stage = None
    backup = backup_root/stamp
    moved_old, installed = [], []
    runtime_changes = []
    stopped = False
    stop_requested = False
    committed = False
    try:
        backup.mkdir(parents=True)
        stage = project.parent/('.pi-course-v2-stage-'+stamp)
        shutil.copytree(source/'pi_basics_6h', stage)
        # 프로젝트 루트 자체를 바꾸지 않아 Docker의 /work 바인드 경로를 유지한다.
        if docker and docker['running']:
            stop_requested = True
            subprocess.run(docker['command']+['stop','--time','10','pi-class'],
                           check=True, capture_output=True, timeout=25)
            stopped = True
        for item in sorted(project.iterdir()):
            if item.name in KEEP:
                continue
            os.replace(item, backup/item.name)
            moved_old.append(item.name)
        for item in sorted(stage.iterdir()):
            if item.name in KEEP:
                continue
            os.replace(item, project/item.name)
            installed.append(item.name)
        model_dir = project/'models'
        model_dir.mkdir(exist_ok=True)
        for incoming in sorted((stage/'models').rglob('*')):
            if not incoming.is_file():
                continue
            rel = incoming.relative_to(stage)
            destination = project/rel
            for ancestor in [destination, *destination.parents]:
                if ancestor.is_symlink():
                    raise ValueError('모델 경로가 심볼릭 링크입니다: '+str(ancestor))
                if ancestor == project:
                    break
            if destination.exists() and not destination.is_file():
                raise ValueError('모델 경로가 일반 파일이 아닙니다: '+str(destination))
            if not destination.exists() or sha(destination) != sha(incoming):
                saved = None
                if destination.exists():
                    saved = backup/'_runtime_files'/rel
                    saved.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(destination, saved)
                destination.parent.mkdir(parents=True, exist_ok=True)
                os.replace(incoming, destination)
                runtime_changes.append((rel.as_posix(), saved is not None))
        # 런타임 경로를 보존한 뒤 배포 파일 전체를 다시 해시 검증한다.
        for entry in manifest['files']:
            rel = Path(entry['path'])
            if rel.parts[0] == 'pi_basics_6h' and sha(project/Path(*rel.parts[1:])) != entry['sha256']:
                raise ValueError('설치 후 해시 불일치: '+entry['path'])
        (backup/'RESET_RECORD.json').write_text(json.dumps({
            'version':VERSION,'project':str(project),'old_entries':moved_old,
            'new_entries':installed,'preserved':sorted(KEEP),
            'runtime_changes':runtime_changes,
            'container':{k:v for k,v in (docker or {}).items() if k != 'command'},
        }, ensure_ascii=False, indent=2)+'\n',encoding='utf-8')
        if stopped:
            subprocess.run(docker['command']+['start','pi-class'], check=True,
                           capture_output=True, timeout=25)
        committed = True
        print('업데이트 완료:', VERSION)
        print('기존 예제 백업:', backup)
        print('다음: cd ~/pi_basics_6h && bash preflight_v2.sh')
        return backup
    except BaseException:
        # 실패하면 교체한 파일을 치우고 기존 파일을 원위치로 되돌린다.
        if stop_requested:
            try:
                subprocess.run(docker['command']+['stop','--time','10','pi-class'],
                               capture_output=True, timeout=25)
            except (OSError, subprocess.SubprocessError) as exc:
                print('컨테이너 종료 재확인 실패: '+str(exc), file=sys.stderr)
        for name in reversed(installed):
            path = project/name
            if path.exists() or path.is_symlink():
                os.replace(path, stage/name)
        for name in reversed(moved_old):
            os.replace(backup/name, project/name)
        for rel, was_present in reversed(runtime_changes):
            destination = project/rel
            if was_present:
                shutil.copy2(backup/'_runtime_files'/rel, destination)
            else:
                destination.unlink(missing_ok=True)
        if stop_requested:
            try:
                result = subprocess.run(docker['command']+['start','pi-class'], capture_output=True, timeout=25)
                if result.returncode:
                    print('기존 코드 복원 후 컨테이너 재시작에 실패했습니다. sudo docker start pi-class로 확인하세요.',file=sys.stderr)
            except (OSError, subprocess.SubprocessError) as exc:
                print('기존 코드 복원 후 Docker 시작 확인 필요: '+str(exc),file=sys.stderr)
        print('업데이트 실패: 기존 예제를 복원했습니다.', file=sys.stderr)
        raise
    finally:
        lock.unlink(missing_ok=True)
        if stage and stage.exists() and committed:
            shutil.rmtree(stage)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--project', type=Path, default=Path.home()/'pi_basics_6h')
    ap.add_argument('--check',action='store_true')
    args = ap.parse_args()
    if hasattr(os,'geteuid') and os.geteuid() == 0:
        raise SystemExit('sudo 없이 student 사용자로 실행하세요.')
    try:
        install(Path(__file__).resolve().parent, args.project.expanduser().absolute(), args.check)
    except (ValueError, OSError, subprocess.SubprocessError) as exc:
        raise SystemExit('중단: '+str(exc))


if __name__ == '__main__':
    main()
